<?php
$servername = "localhost";
$username   = "u137169874_codex";
$password   = "Codex@1208";
$database   = "u137169874_codex";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function getConnection() {
    global $conn;
    return $conn;
}
?>