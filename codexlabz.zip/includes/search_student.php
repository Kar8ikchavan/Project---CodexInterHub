<?php
require_once '../config/database.php';
$conn = getConnection();

$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

if ($search) {
    $sql = "SELECT * FROM students WHERE name LIKE '%$search%' OR email LIKE '%$search%'";
    $result = mysqli_query($conn, $sql);
    
    echo '<option value="">Select a student</option>';
    while($row = mysqli_fetch_assoc($result)) {
        echo '<option value="' . $row['id'] . '">' . 
             htmlspecialchars($row['name'] . ' (' . $row['email'] . ')') . 
             '</option>';
    }
}
?>