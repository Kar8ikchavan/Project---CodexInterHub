<?php
require_once '../config/database.php';
$conn = getConnection();

$course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;

if ($course_id > 0) {
    $sql = "SELECT * FROM batches WHERE course_id = $course_id";
    $result = mysqli_query($conn, $sql);
    
    echo '<option value="0">No Batch</option>';
    while($row = mysqli_fetch_assoc($result)) {
        echo '<option value="' . $row['id'] . '">' . 
             htmlspecialchars($row['batch_name'] . ' (' . $row['batch_code'] . ')') . 
             '</option>';
    }
}
?>