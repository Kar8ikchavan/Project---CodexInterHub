                </div> <!-- Close container -->
            </div> <!-- Close col-md-10 -->
        </div> <!-- Close row -->
    </div> <!-- Close container-fluid -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <script>
    // Auto-dismiss alerts
    $(document).ready(function() {
        $('.alert').delay(3000).fadeOut('slow');
    });
    
    // Confirm delete
    function confirmDelete() {
        return confirm("Are you sure you want to delete this?");
    }
    </script>
</body>
</html>