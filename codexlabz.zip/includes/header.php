<?php
require_once '../config/database.php';
requireLogin();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CodexLabz Internship - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
            border-bottom: 1px solid #495057;
        }
        .sidebar a:hover {
            background: #495057;
        }
        .sidebar a.active {
            background: #007bff;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-0">
                <div class="p-3 bg-dark text-white">
                    <h4>CodexLabz</h4>
                    <small>Internship System</small>
                </div>
                <nav class="nav flex-column">
                    <a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                    <a href="students.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'students.php' ? 'active' : ''; ?>">
                        <i class="fas fa-users"></i> Students
                    </a>
                    <a href="courses.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'courses.php' ? 'active' : ''; ?>">
                        <i class="fas fa-book"></i> Courses
                    </a>
                    <a href="batches.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'batches.php' ? 'active' : ''; ?>">
                        <i class="fas fa-layer-group"></i> Batches
                    </a>
                    <a href="certificates.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'certificates.php' ? 'active' : ''; ?>">
                        <i class="fas fa-certificate"></i> Certificates
                    </a>
                    <a href="change_password.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'change_password.php' ? 'active' : ''; ?>">
                        <i class="fas fa-key"></i> Change Password
                    </a>
                    <a href="../index.php?logout=1" class="text-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-10">
                <nav class="navbar navbar-light bg-light">
                    <div class="container-fluid">
                        <span class="navbar-brand">Admin Panel</span>
                        <span class="navbar-text">
                            Welcome, <?php echo $_SESSION['admin_name']; ?>
                        </span>
                    </div>
                </nav>
                <div class="container mt-4">