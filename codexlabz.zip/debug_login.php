<?php
// Debug script for login issues
session_start();
include 'config/database.php';
echo "<pre>";

// Test password hash
$password = 'admin123';
$hash = password_hash($password, PASSWORD_DEFAULT);
echo "Password: $password\n";
echo "Hash: $hash\n";
echo "Verify: " . (password_verify($password, $hash) ? 'YES' : 'NO') . "\n\n";

// Test database connection
#$conn = new mysqli('localhost', 'root', '', 'codexlabz_internship');

if ($conn->connect_error) {
    echo "Database connection failed: " . $conn->connect_error . "\n";
} else {
    echo "Database connected successfully!\n";
    
    // Check admin table
    $result = $conn->query("SELECT * FROM admin");
    if ($result) {
        echo "Admin table exists. Records: " . $result->num_rows . "\n";
        while($row = $result->fetch_assoc()) {
            print_r($row);
            echo "\nPassword verify test: ";
            echo password_verify('admin123', $row['password']) ? 'SUCCESS' : 'FAILED';
            echo "\n";
        }
    } else {
        echo "Error reading admin table: " . $conn->error . "\n";
    }
    
    $conn->close();
}

// Check session
echo "\nSession data:\n";
print_r($_SESSION);

// Check if session is working
$_SESSION['test'] = 'session_works';
echo "\nSession test: " . $_SESSION['test'] . "\n";

echo "</pre>";
?>