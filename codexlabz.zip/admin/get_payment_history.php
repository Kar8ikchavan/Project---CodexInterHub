<?php
require_once 'header.php';
require_once '../config/database.php';

$conn = getConnection();

if (isset($_GET['batch_id']) && isset($_GET['student_id'])) {
    $batch_id = intval($_GET['batch_id']);
    $student_id = intval($_GET['student_id']);
    
    // Get student info
    $student_query = $conn->query("SELECT name FROM students WHERE id = $student_id");
    $student_info = $student_query ? $student_query->fetch_assoc() : null;
    $student_name = $student_info['name'] ?? 'Unknown Student';
    
    // Get fee summary
    $fee_query = $conn->query("SELECT total_fee, paid_amount, remaining_fee 
                               FROM batch_fees 
                               WHERE batch_id = $batch_id AND student_id = $student_id");
    $fee_summary = $fee_query ? $fee_query->fetch_assoc() : null;
    
    // Get payment history
    $payments = $conn->query("SELECT * FROM fee_payments 
                              WHERE batch_id = $batch_id AND student_id = $student_id 
                              ORDER BY payment_date DESC, created_at DESC");
    ?>
    
    <div style="margin-bottom: 20px;">
        <h4 style="margin: 0 0 10px 0;">
            Payment History for <?php echo htmlspecialchars($student_name); ?>
        </h4>
        
        <?php if ($fee_summary): ?>
        <div style="background: #f8f9fa; padding: 15px; border-radius: 6px; margin-bottom: 20px;">
            <div style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
                <div>
                    <div style="font-size: 12px; color: #6c757d;">Total Fee</div>
                    <div style="font-size: 18px; font-weight: 600; color: #2c3e50;">
                        ₹<?php echo number_format($fee_summary['total_fee'], 2); ?>
                    </div>
                </div>
                <div>
                    <div style="font-size: 12px; color: #6c757d;">Paid Amount</div>
                    <div style="font-size: 18px; font-weight: 600; color: #28a745;">
                        ₹<?php echo number_format($fee_summary['paid_amount'], 2); ?>
                    </div>
                </div>
                <div>
                    <div style="font-size: 12px; color: #6c757d;">Remaining Fee</div>
                    <div style="font-size: 18px; font-weight: 600; color: #dc3545;">
                        ₹<?php echo number_format($fee_summary['remaining_fee'], 2); ?>
                    </div>
                </div>
            </div>
            
            <div style="margin-top: 10px; background: #e9ecef; height: 8px; border-radius: 4px; overflow: hidden;">
                <div style="background: #28a745; height: 100%; width: 
                    <?php 
                        echo ($fee_summary['total_fee'] > 0) 
                        ? min(100, ($fee_summary['paid_amount'] / $fee_summary['total_fee']) * 100) 
                        : 0; 
                    ?>%;
                "></div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <?php if ($payments && $payments->num_rows > 0): ?>
    <div style="overflow-x: auto;">
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="background: #e9ecef;">
                    <th style="padding: 10px; text-align: left;">Date</th>
                    <th style="padding: 10px; text-align: left;">Amount</th>
                    <th style="padding: 10px; text-align: left;">Method</th>
                    <th style="padding: 10px; text-align: left;">Reference</th>
                    <th style="padding: 10px; text-align: left;">Notes</th>
                    <th style="padding: 10px; text-align: left;">Time</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($payment = $payments->fetch_assoc()): ?>
                <tr style="border-bottom: 1px solid #dee2e6;">
                    <td style="padding: 10px;">
                        <?php echo date('d M Y', strtotime($payment['payment_date'])); ?>
                    </td>
                    <td style="padding: 10px; font-weight: 600; color: #28a745;">
                        ₹<?php echo number_format($payment['amount'], 2); ?>
                    </td>
                    <td style="padding: 10px;">
                        <span style="background: #007bff; color: white; padding: 3px 8px; border-radius: 12px; font-size: 12px;">
                            <?php echo ucfirst(str_replace('_', ' ', $payment['payment_method'])); ?>
                        </span>
                    </td>
                    <td style="padding: 10px; color: #6c757d;">
                        <?php echo $payment['reference_no'] ?: 'N/A'; ?>
                    </td>
                    <td style="padding: 10px; color: #6c757d;">
                        <?php echo htmlspecialchars($payment['notes'] ?? ''); ?>
                    </td>
                    <td style="padding: 10px; color: #6c757d; font-size: 12px;">
                        <?php echo date('h:i A', strtotime($payment['created_at'])); ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div style="text-align: center; padding: 40px; color: #6c757d;">
        <h4 style="margin: 0 0 10px 0;">No Payment History</h4>
        <p style="margin: 0;">No payments have been recorded for this student yet.</p>
    </div>
    <?php endif; ?>
    
    <?php
} else {
    echo '<div style="text-align: center; padding: 40px; color: #f44336;">Invalid request</div>';
}

$conn->close();
?>
