<?php
// verify_certificate.php
require_once 'header.php';

$conn = getConnection();

$certificate_code = isset($_GET['code']) ? $_GET['code'] : '';

if (!empty($certificate_code)) {
    $sql = "SELECT c.*, s.name as student_name, s.gender, 
                   cr.name as course_name, cr.start_date as course_start, 
                   cr.end_date as course_end, b.batch_code
            FROM certificates c
            JOIN students s ON c.student_id = s.id
            JOIN courses cr ON c.course_id = cr.id
            LEFT JOIN batches b ON c.batch_id = b.id
            WHERE c.certificate_code = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $certificate_code);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        $certificate = $result->fetch_assoc();
        $status = "VALID";
        $status_color = "success";
    } else {
        $status = "INVALID";
        $status_color = "danger";
        $certificate = null;
    }
} else {
    $status = "NO CODE PROVIDED";
    $status_color = "warning";
}

$conn->close();
?>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-check-circle"></i> Certificate Verification</h3>
    </div>
    
    <div style="padding: 40px; text-align: center;">
        <?php if(isset($certificate_code) && !empty($certificate_code)): ?>
            <div style="margin-bottom: 30px;">
                <h4>Certificate Code: <?php echo htmlspecialchars($certificate_code); ?></h4>
                <div class="status-badge badge-<?php echo $status_color; ?>" 
                     style="font-size: 20px; padding: 10px 30px; display: inline-block;">
                    <?php echo $status; ?>
                </div>
            </div>
            
            <?php if($status == "VALID"): ?>
                <!-- Show certificate details -->
                <div class="card" style="max-width: 600px; margin: 0 auto;">
                    <div class="card-header" style="background: #f8f9fa;">
                        <h5>Certificate Details</h5>
                    </div>
                    <div style="padding: 20px;">
                        <div style="display: grid; grid-template-columns: 1fr; gap: 15px;">
                            <div>
                                <p style="color: #7f8c8d; margin: 0;">Student Name</p>
                                <p style="font-weight: bold;"><?php echo htmlspecialchars($certificate['student_name']); ?></p>
                            </div>
                            <div>
                                <p style="color: #7f8c8d; margin: 0;">Course Name</p>
                                <p style="font-weight: bold;"><?php echo htmlspecialchars($certificate['course_name']); ?></p>
                            </div>
                            <div>
                                <p style="color: #7f8c8d; margin: 0;">Issue Date</p>
                                <p style="font-weight: bold;"><?php echo date('d M Y', strtotime($certificate['issue_date'])); ?></p>
                            </div>
                            <div>
                                <p style="color: #7f8c8d; margin: 0;">Batch Code</p>
                                <p style="font-weight: bold;"><?php echo $certificate['batch_code'] ?? 'N/A'; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div style="padding: 30px; background: #f8d7da; color: #721c24; border-radius: 8px; max-width: 500px; margin: 0 auto;">
                    <i class="fas fa-exclamation-triangle" style="font-size: 48px; margin-bottom: 15px;"></i>
                    <h4>Certificate Not Found</h4>
                    <p>This certificate code is not valid or does not exist in our database.</p>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <!-- Verification form -->
            <div style="max-width: 500px; margin: 0 auto;">
                <div style="margin-bottom: 30px;">
                    <h4>Verify Certificate Authenticity</h4>
                    <p>Enter the certificate code to verify</p>
                </div>
                
                <form method="GET" style="display: flex; gap: 10px;">
                    <input type="text" name="code" placeholder="Enter Certificate Code (e.g., CERT-ABCD123)" 
                           style="flex: 1; padding: 12px; border: 1px solid #ddd; border-radius: 5px;"
                           required>
                    <button type="submit" class="btn-primary" style="padding: 12px 25px;">
                        <i class="fas fa-search"></i> Verify
                    </button>
                </form>
                
                <div style="margin-top: 30px; color: #7f8c8d;">
                    <p><i class="fas fa-info-circle"></i> Certificate codes are unique identifiers printed on certificates</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.status-badge {
    padding: 5px 15px;
    border-radius: 20px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.badge-success {
    background: #d4edda;
    color: #155724;
    border: 2px solid #c3e6cb;
}

.badge-danger {
    background: #f8d7da;
    color: #721c24;
    border: 2px solid #f5c6cb;
}

.badge-warning {
    background: #fff3cd;
    color: #856404;
    border: 2px solid #ffeaa7;
}
</style>

<?php require_once 'footer.php'; ?>