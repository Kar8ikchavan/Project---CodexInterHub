<?php
require_once 'header.php'; // or require_once '../config/database.php' depending on your structure

$conn = getConnection();

$course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;

if ($course_id > 0) {
    // Get all batches for this course (both active and completed)
    $batches = $conn->query("SELECT id, batch_name, batch_code, start_date, end_date, status 
                             FROM batches 
                             WHERE course_id = $course_id 
                             ORDER BY 
                                 CASE status 
                                     WHEN 'active' THEN 1 
                                     WHEN 'completed' THEN 2 
                                     ELSE 3 
                                 END, 
                                 start_date DESC");
    
    $options = '<option value="">Select Batch</option>';
    
    if ($batches && $batches->num_rows > 0) {
        while ($batch = $batches->fetch_assoc()) {
            $status_badge = ($batch['status'] == 'active') ? ' (Active)' : ' (Completed)';
            $options .= '<option value="' . $batch['id'] . '">' 
                      . htmlspecialchars($batch['batch_name']) . ' - ' 
                      . htmlspecialchars($batch['batch_code']) 
                      . $status_badge 
                      . ' [' . date('d M Y', strtotime($batch['start_date'])) . ' to ' . date('d M Y', strtotime($batch['end_date'])) . ']'
                      . '</option>';
        }
    } else {
        $options = '<option value="">No batches found for this course</option>';
    }
    
    echo $options;
} else {
    echo '<option value="">Invalid course</option>';
}

$conn->close();
?>