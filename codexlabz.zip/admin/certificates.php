<?php
require_once 'header.php';

$conn = getConnection();
$message = '';


// Check if viewing a specific certificate
$view_certificate_id = isset($_GET['view']) ? intval($_GET['view']) : 0;
$certificate_data = null;

if ($view_certificate_id > 0) {
    $sql = "SELECT c.*, s.name as student_name, s.gender, s.email,
                   cr.name as course_name, 
                   b.start_date as batch_start, b.end_date as batch_end, b.batch_code
            FROM certificates c
            JOIN students s ON c.student_id = s.id
            JOIN courses cr ON c.course_id = cr.id
            LEFT JOIN batches b ON c.batch_id = b.id
            WHERE c.id = $view_certificate_id";
    
    $result = $conn->query($sql);
    
    if ($result->num_rows == 1) {
        $certificate_data = $result->fetch_assoc();
        // CHANGED: Set salutation based on gender - Mr. for male, Ms. for female
        if ($certificate_data['gender'] == 'Female') {
            $salutation = 'Ms.';
        } else {
            $salutation = 'Mr.';
        }
        
        // Format dates
        function formatCertificateDate($date) {
            if (!$date) return 'N/A';
            $day = date('jS', strtotime($date));
            $month_year = date('F Y', strtotime($date));
            return $day . ' ' . $month_year;
        }
        
        // Use batch dates if available
        if (!empty($certificate_data['batch_start']) && !empty($certificate_data['batch_end'])) {
            $course_start_formatted = date('d/m/Y', strtotime($certificate_data['batch_start']));
            $course_end_formatted = date('d/m/Y', strtotime($certificate_data['batch_end']));
        } else {
            $course_start_formatted = 'N/A';
            $course_end_formatted = 'N/A';
        }
        
        // Generate QR code URL
        $certificate_url = "https://" . $_SERVER['HTTP_HOST'] . "/public/view_certificate.php?ref=" . urlencode($certificate_data['certificate_code']);
        $qr_code_url = "https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=" . urlencode($certificate_url);
    }
}

// Generate Certificate
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['generate_certificate'])) {
    $student_id = intval($_POST['student_id']);
    $course_id = intval($_POST['course_id']);
    $batch_id = intval($_POST['batch_id']);
    $issue_date = $conn->real_escape_string($_POST['issue_date']);
    $certificate_code = 'CERT-' . strtoupper(uniqid());
    
    $check = $conn->query("SELECT id FROM certificates WHERE student_id = $student_id AND course_id = $course_id");
    
    if ($check->num_rows > 0) {
        $message = '<div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> Certificate already exists for this student!</div>';
    } else {
        $sql = "INSERT INTO certificates (certificate_code, student_id, course_id, batch_id, issue_date) 
                VALUES ('$certificate_code', $student_id, $course_id, $batch_id, '$issue_date')";
        
        if ($conn->query($sql)) {
            $message = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Certificate generated! Code: ' . $certificate_code . '</div>';
        } else {
            $message = '<div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> Error: ' . $conn->error . '</div>';
        }
    }
}

// Delete Certificate
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM certificates WHERE id = $id");
    $message = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Certificate deleted successfully!</div>';
}

// Get certificates
$certificates = $conn->query("SELECT c.*, s.name as student_name, s.gender, 
                             cr.name as course_name, cr.start_date as course_start, 
                             cr.end_date as course_end, b.batch_code
                             FROM certificates c
                             JOIN students s ON c.student_id = s.id
                             JOIN courses cr ON c.course_id = cr.id
                             LEFT JOIN batches b ON c.batch_id = b.id
                             ORDER BY c.id DESC");

// Get all courses for dropdown
$all_courses = $conn->query("SELECT * FROM courses ORDER BY name");
?>

<style>


        /* Alerts */
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.3s ease;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @keyframes slideIn {
            from { transform: translateY(-10px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        /* Card Styles */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            overflow: hidden;
            margin-bottom: 30px;
        }
        
        .card-header {
            padding: 25px;
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .card-header h3 {
            font-size: 24px;
            display: flex;
            align-items: center;
            color: white;
            gap: 10px;
        }
        
        /* Buttons */
        .btn-primary, .btn-secondary, .btn-success, .btn-danger {
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 15px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-sm {
            padding: 8px 16px;
            font-size: 14px;
        }
        
        /* Table Styles */
        .table-container {
            overflow-x: auto;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }
        
        thead {
            background: #f8f9fa;
        }
        
        th {
            padding: 18px 15px;
            text-align: left;
            font-weight: 600;
            color: #495057;
            border-bottom: 2px solid #dee2e6;
        }
        
        td {
            padding: 16px 15px;
            border-bottom: 1px solid #e0e0e0;
            vertical-align: middle;
        }
        
        tbody tr:hover {
            background: #f8f9ff;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            z-index: 1000;
            overflow-y: auto;
            padding: 20px;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            margin: 50px auto;
            max-width: 800px;
            animation: modalSlideIn 0.3s ease;
        }
        
        @keyframes modalSlideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        .modal-header {
            padding: 25px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-header h3 {
            color: #2c3e50;
            font-size: 22px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .close-modal {
            background: none;
            border: none;
            font-size: 28px;
            color: #7f8c8d;
            cursor: pointer;
            transition: color 0.3s;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }
        
        .close-modal:hover {
            color: #e74c3c;
            background: #f9f9f9;
        }
        
        /* Form Styles */
        .form-group {
            margin-bottom: 20px;
            padding: 0 25px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #2c3e50;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: #667eea;
            outline: none;
        }
        
        .modal-footer {
            padding: 25px;
            border-top: 1px solid #e0e0e0;
            display: flex;
            justify-content: flex-end;
            gap: 15px;
        }
        
        /* Horizontal Certificate Modal - Landscape */
        #certificateModal .modal-content {
            max-width: 1200px;
            width: 95%;
        }
        
        .certificate-display-container {
            padding: 25px 30px;
            background: #f0f2f5;
        }
        
        /* Professional Corporate Certificate Design */
        .certificate-preview {
            display: flex;
            justify-content: center;
            margin-bottom: 25px;
        }
        
        .certificate-paper {
            max-width: 1100px;
            width: 100%;
            background: #ffffff;
            box-shadow: 0 20px 40px -12px rgba(0, 0, 0, 0.2);
            position: relative;
            transition: all 0.2s;
        }
        
        .certificate-inner {
            position: relative;
            width: 100%;
            padding: 32px 40px 36px 40px;
            display: flex;
            flex-direction: column;
            background: white;
        }
        
        /* Double border: elegant corporate style */
        .double-border {
            position: absolute;
            top: 14px;
            left: 14px;
            right: 14px;
            bottom: 14px;
            pointer-events: none;
            z-index: 2;
        }
        .outer-border {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border: 2.5px solid #1a3e50;
        }
        .inner-border {
            position: absolute;
            top: 8px;
            left: 8px;
            right: 8px;
            bottom: 8px;
            border: 1px solid #c7a03a;
        }
        
        /* Triangle decorations */
        .triangle-left-top {
            position: absolute;
            top: 14px;
            left: 14px;
            width: 200px;
            height: 0;
            border-style: solid;
            border-width: 35px 35px 0 0;
            border-color: #1f2858 transparent transparent transparent;
            z-index: 3;
            pointer-events: none;
        }
        
        .triangle-right-bottom {
            position: absolute;
            bottom: 14px;
            right: 14px;
            width: 200px;
            height: 0;
            border-style: solid;
            border-width: 0 0 35px 35px;
            border-color: transparent transparent #1f2858 transparent;
            z-index: 3;
            pointer-events: none;
        }
        
        /* Watermark pattern */
        .bg-watermark {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: radial-gradient(circle at 30% 50%, rgba(199, 160, 58, 0.02) 2%, transparent 2.5%),
                              radial-gradient(circle at 70% 85%, rgba(26, 62, 80, 0.015) 1.8%, transparent 2%);
            background-size: 50px 50px, 40px 40px;
            pointer-events: none;
            z-index: 0;
        }
        
        .content {
            position: relative;
            z-index: 5;
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        
        /* Top: Certificate ID */
        .cert-id-top {
            text-align: right;
            font-family: 'Inter', monospace;
            font-size: 13px;
            font-weight: 500;
            color: #4a6f7e;
            letter-spacing: 0.5px;
            display: inline-block;
            align-self: flex-end;
            padding: 6px 14px;
            margin-bottom: 16px;
        }
        
        /* Title area */
        .title-section {
            text-align: center;
            margin: 8px 0 8px 0;
        }
        .main-title {
            font-size: 52px;
            letter-spacing: 5px;
            color: #1a3e50;
            text-transform: uppercase;
            margin-bottom: 6px;
            font-family: Times New Roman;
        }
        .subtitle {
            font-family: 'Inter', sans-serif;
            font-size: 16px;
            font-weight: 500;
            color: #6b7f8c;
            letter-spacing: 3px;
            text-transform: uppercase;
            display: inline-block;
            padding-top: 8px;
            padding-left: 12px;
            padding-right: 12px;
        }
        
        /* Student name */
        .student-name-section {
            text-align: center;
            margin: 18px 0 20px 0;
        }
        .name-highlight {
            border-bottom: 2px solid #1f2858;
            padding: 18px 24px;
            width: 80%;
            margin: 0 auto;
        }
        .student-fullname {
            font-family: 'Roboto', Sans-Serif;
            font-size: 46px;
            font-weight: 600;
            color: #1a3e50;
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }
        
        /* Completion text */
        .completion-text {
            text-align: center;
            font-family: 'Inter', sans-serif;
            font-size: 20px;
            line-height: 1.6;
            color: #2c3f4c;
            margin: 12px 0 8px 0;
        }
        .completion-text p {
            margin-bottom: 8px;
        }
        .domain-highlight {
            font-weight: 800;
            color: #1a3e50;
        }
        .company-name {
            font-weight: 800;
            letter-spacing: 1px;
            color: #1a3e50;
            display: inline-block;
            padding: 0 8px;
        }
        .duration-text {
            font-family: monospace;
            font-weight: 600;
            padding: 2px 8px;
            border-radius: 20px;
            font-size: 20px;
        }
        
        /* Appreciation paragraph */
        .appreciation {
            text-align: center;
            max-width: 90%;
            margin: 18px auto 12px auto;
            font-family: 'Inter', sans-serif;
            font-size: 20px;
            line-height: 1.55;
            color: #2c3f4c;
            padding: 12px 18px;
        }
        
        /* Bottom section */
        .bottom-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-top: 18px;
            gap: 24px;
            flex-wrap: wrap;
        }
        
        /* QR Box */
        .qr-box {
            width: 110px;
            height: 110px;
            background: #f8fafc;
            border: 1.5px solid #dce5ec;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.05);
            margin-left: 70px;
        }
        .qr-img {
            width: 78px;
            height: 78px;
            object-fit: contain;
            cursor: pointer;
        }
        .qr-label {
            font-size: 8px;
            margin-top: 6px;
            color: #5f7d8c;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.6px;
        }
        
        /* Signature area */
        .signature-area {
            text-align: center;
            min-width: 200px;
            flex: 1;
            margin-right: 250px;
        }
        
       
        .signature-line {
            border-bottom: 1px solid #1a3e50;
            width: 150px;
            margin-right:8px ;
            padding-top: 8px;
            
        }
        
        .signature-label {
            font-family: 'Inter', sans-serif;
            font-size: 13px;
            font-weight: 600;
            color: #3e5e6e;
            letter-spacing: 1px;
            text-transform: uppercase;
            background: white;
            display: inline-block;
            padding: 0 8px;
        }
        .signature-sub {
            font-size: 10px;
            color: #7c95a3;
            margin-top: 4px;
        }
        
        /* Partner logos */
        .partner-logos {
            display: flex;
            gap: 24px;
            align-items: center;
            margin-right: 100px;
        }
        .logo-box {
            width: 85px;
            height: 80px;
            background: #ffffff;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            box-shadow: 0 1px 5px rgba(0,0,0,0.02);
            
        }
        .logo-icon {
            font-size: 32px;
            font-weight: 700;
            margin-right:250px;
            color: #1a3e50;
            font-family: 'Times New Roman', serif;
        }
        .logo-caption {
            font-size: 9px;
            font-weight: 600;
            color: #6f8ea0;
            margin-top: 5px;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }
        
        /* Footer */
        .footer-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
            padding-top: 12px;
            border-top: 1px solid #e2e8f0;
            font-family: 'Inter', sans-serif;
            font-size: 11px;
            color: #5f7f8c;
        }
        
        .certificate-actions {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin: 20px 0;
            flex-wrap: wrap;
        }
        
        .certificate-details {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 25px;
            margin-top: 30px;
        }
        
        .certificate-details h4 {
            margin-bottom: 20px;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 15px;
        }
        
        .detail-item {
            display: flex;
            justify-content: space-between;
            padding: 12px;
            background: white;
            border-radius: 8px;
            border-left: 4px solid #c7a03a;
        }
        
        .detail-label {
            font-weight: 600;
            color: #555;
        }
        
        .detail-value {
            color: #2c3e50;
            font-weight: 500;
        }
        
        /* No Data State */
        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: #7f8c8d;
        }
        
        .no-data i {
            font-size: 64px;
            margin-bottom: 20px;
            opacity: 0.3;
        }
        
        .no-data h3 {
            margin-bottom: 10px;
            color: #95a5a6;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .card-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .modal-content {
                margin: 20px auto;
                width: 95%;
            }
            
            .certificate-inner {
                padding: 20px;
            }
            
            .student-fullname {
                font-size: 28px;
            }
            
            .main-title {
                font-size: 34px;
            }
            
            .bottom-row {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .footer-info {
                flex-direction: column;
                gap: 6px;
                text-align: center;
            }
            
            .name-highlight {
                width: 95%;
                padding: 12px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .certificate-actions {
                flex-direction: column;
            }
            
            .certificate-actions button {
                width: 100%;
            }
            
            .details-grid {
                grid-template-columns: 1fr;
            }
            
            table {
                font-size: 14px;
            }
        }
        
        /* Print Styles for Landscape */
        @media print {
            @page {
                size: landscape;
                margin: 0.5cm;
            }
            
            body * {
                visibility: hidden;
            }
            
            .certificate-paper,
            .certificate-paper * {
                visibility: visible;
            }
            
            .certificate-paper {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                box-shadow: none;
                margin: 0;
            }
            
            .certificate-actions,
            .certificate-details {
                display: none !important;
            }
        }
        .n{
            margin-left: 300px;
        }
        .signarea{
            display: flex;
            align-items: center;
            text-align: center;
            gap: 50px;
            justify-content: space-between;
            
        }
        
        .signarea s{
        
            margin-left: 20px;
        }
        }
        .certified{

            position: absolute;
        }
        .certified img{
            margin-left: 800px;
            margin-top: 90px;
            position: absolute;
            height: 200px;
            
        }

       
</style>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-certificate"></i> Certificates Management</h3>
            <button class="btn-primary" onclick="openModal('generateCertModal')">
                <i class="fas fa-plus-circle"></i> Generate Certificate
            </button>
        </div>
        
        <div style="padding: 25px;">
            <?php echo $message; ?>
            
            <?php if($certificates->num_rows > 0): ?>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Certificate Code</th>
                            <th>Student</th>
                            <th>Course</th>
                            <th>Batch</th>
                            <th>Issue Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $certificates->fetch_assoc()): 
                            // CHANGED: Set salutation for table display
                            $row_salutation = ($row['gender'] == 'Female') ? 'Ms.' : 'Mr.';
                        ?>
                        <tr>
                            <td>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #9C27B0 0%, #673AB7 100%); 
                                          border-radius: 8px; display: flex; align-items: center; justify-content: center; color: white;">
                                        <i class="fas fa-certificate"></i>
                                    </div>
                                    <span style="font-weight: 500;"><?php echo htmlspecialchars($row['certificate_code']); ?></span>
                                </div>
                             </div>
                             <!-- CHANGED: Added salutation before student name -->
                             <td><?php echo $row_salutation . ' ' . htmlspecialchars($row['student_name']); ?></td>
                             <td><?php echo htmlspecialchars($row['course_name']); ?></td>
                             <td>
                                <?php if($row['batch_code']): ?>
                                    <span style="background: #e3f2fd; color: #1976d2; padding: 4px 12px; border-radius: 20px; font-size: 13px; font-weight: 500;">
                                        <?php echo htmlspecialchars($row['batch_code']); ?>
                                    </span>
                                <?php else: ?>
                                    <span style="color: #95a5a6;">N/A</span>
                                <?php endif; ?>
                             </td>
                             <td>
                                <div style="display: flex; align-items: center; gap: 8px;">
                                    <i class="far fa-calendar" style="color: #7f8c8d;"></i>
                                    <?php echo date('d M Y', strtotime($row['issue_date'])); ?>
                                </div>
                             </td>
                             <td>
                                <div class="action-buttons">
                                    <button onclick="viewCertificate(<?php echo $row['id']; ?>)" 
                                            class="btn-primary btn-sm">
                                        <i class="fas fa-eye"></i> View
                                    </button>
                                    <a href="?delete=<?php echo $row['id']; ?>" 
                                       class="btn-danger btn-sm" 
                                       onclick="return confirm('Are you sure you want to delete this certificate?')">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </div>
                             </td>
                          </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="no-data">
                <i class="fas fa-certificate"></i>
                <h3>No Certificates Found</h3>
                <p>Generate your first certificate to get started</p>
                <button class="btn-primary" onclick="openModal('generateCertModal')" style="margin-top: 20px;">
                    <i class="fas fa-plus-circle"></i> Generate Certificate
                </button>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Generate Certificate Modal -->
<div id="generateCertModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-certificate"></i> Generate Certificate</h3>
            <button class="close-modal" onclick="closeModal('generateCertModal')">&times;</button>
        </div>
        <form method="POST" id="generateCertForm">
            <div class="form-group">
                <label>Select Course *</label>
                <select name="course_id" id="courseSelect" class="form-control" required 
                        onchange="loadBatchesAndStudents(this.value)">
                    <option value="">Select Course</option>
                    <?php 
                    if ($all_courses->num_rows > 0):
                        $all_courses->data_seek(0);
                        while($course = $all_courses->fetch_assoc()): 
                    ?>
                        <option value="<?php echo $course['id']; ?>">
                            <?php echo htmlspecialchars($course['name']); ?> 
                            (<?php echo ucfirst($course['status']); ?>)
                        </option>
                    <?php 
                        endwhile;
                    else: 
                    ?>
                        <option value="" disabled>No courses found</option>
                    <?php endif; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Select Batch *</label>
                <select name="batch_id" id="batchSelect" class="form-control" required onchange="loadStudentsByBatch(this.value)">
                    <option value="">First select a course</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Select Student *</label>
                <select name="student_id" id="studentSelect" class="form-control" required>
                    <option value="">First select a batch</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Issue Date *</label>
                <input type="date" name="issue_date" class="form-control" 
                       value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('generateCertModal')">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="submit" name="generate_certificate" class="btn-primary">
                    <i class="fas fa-certificate"></i> Generate Certificate
                </button>
            </div>
        </form>
    </div>
</div>

<!-- View Certificate Modal - Horizontal Professional Design -->
<?php if ($certificate_data): ?>
<div id="certificateModal" class="modal" style="display: block;">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-certificate"></i> Certificate: <?php echo htmlspecialchars($certificate_data['certificate_code']); ?></h3>
            <button class="close-modal" onclick="closeCertificateModal()">&times;</button>
        </div>
        
        
        
        
        
        
        
                         
        
        <div class="certificate-display-container">
            
        
            <!-- Professional Horizontal Certificate Design -->
            <div class="certificate-preview">
                <div class="certificate-paper">
                    <div class="certificate-inner">
                        
                        
                        
                        <div class="certified">
                 <img src="certified.jpg">
                </div>
                
                        <!-- Double border -->
                        
                        <div class="double-border">
                            <div class="outer-border"></div>
                            <div class="inner-border"></div>
                        </div>
                        
                        <!-- Triangle decorations -->
                        <div class="triangle-left-top"></div>
                        <div class="triangle-right-bottom"></div>
                        
                        <div class="bg-watermark"></div>
                        
                        <div class="content">
                            <!-- Certificate ID at top -->
                            <div class="cert-id-top">
                                C.ID: <?php echo htmlspecialchars($certificate_data['certificate_code']); ?>
                            </div>
                            <div class="n">
                                <img src="codex.png">
                            </div>
                            <!-- Large title -->
                            <div class="title-section">
                                <div class="main-title">CERTIFICATE</div>
                                <div class="subtitle">PROUDLY PRESENTED TO</div>
                            </div>
                        
                        
                            <!-- Student full name -->
                            <div class="student-name-section">
                                <div class="name-highlight">
                                    <div class="student-fullname"><?php echo strtoupper(htmlspecialchars($certificate_data['student_name'])); ?></div>
                                </div>
                            </div>
                            
                            <!-- Main content -->
                            <div class="completion-text">
                                <p> has successfully completed a <strong>3 months internship </strong> in</p>
                                <p><span class="domain-highlight"><?php echo htmlspecialchars($certificate_data['course_name']); ?> <span class="company-name"><span>at</span> CODEXLABZ TECHNOLOGIES</span></p>
                                <p><span class="duration-text">from <?php echo $course_start_formatted; ?> to <?php echo $course_end_formatted; ?></span></p>
                            </div>
                            
                            <!-- CHANGED: Appreciation paragraph with proper salutation and pronoun -->
                            <div class="appreciation">
                                <p>    We were truly amazed by <?php echo ($certificate_data['gender'] == 'Female') ? 'her' : 'his'; ?> technical proficiency, problem-solving mindset, and quality of deliverables. <p>The invaluable contributions to projects and collaborative spirit exceeded all expectations.</p>
                            </div>
                            
                            <!-- Bottom section -->
                            <div class="bottom-row">
                                <!-- QR code -->
                                <div class="qr-box">
                                    <img src="<?php echo $qr_code_url; ?>" alt="QR Code" class="qr-img" onclick="showQRInfo()">
                                    <div class="qr-label">Scan to Verify</div>
                                </div>
                                
                                
                                
                                <div class="signarea">
                                    <div class="s">
                                    <img src="sign_founder.png" class="img_founder" height="80px">
                                   <div class="signature-line"></div>
                                <div class="signature-label">FOUNDER</div>
                                </div>
                                
                                 <div class="s">
                                    <img src="sign_black.png" class="img_manager" height="80px">
                                   <div class="signature-line"></div>
                                <div class="signature-label">MANAGER</div>
                                </div>
                                </div>
                                
                                
                                
                                <!-- Partner logos -->
                                <div class="partner-logos">
                                  
                                    <div class="logo-box">
                                        <img  src="msme_logo.webp" height="70px">
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Footer -->
                            <div class="footer-info">
                                <div class="footer-email">📩 info@codexlabz.com</div>
                                <div class="footer-website">🌐 www.codexlabz.com</div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Action Buttons -->
            <div class="certificate-actions">
                <button onclick="printCertificate()" class="btn-primary">
                    <i class="fas fa-print"></i> Print Certificate
                </button>
                <button onclick="shareCertificate()" class="btn-secondary">
                    <i class="fas fa-share-alt"></i> Share Certificate
                </button>
                <button onclick="closeCertificateModal()" class="btn-danger">
                    <i class="fas fa-times"></i> Close View
                </button>
            </div>
            
            <!-- CHANGED: Certificate Details with salutation -->
            <div class="certificate-details">
                <h4><i class="fas fa-info-circle"></i> Certificate Details</h4>
                <div class="details-grid">
                    <div class="detail-item">
                        <span class="detail-label">Student Name:</span>
                        <span class="detail-value"><?php echo $salutation . ' ' . htmlspecialchars($certificate_data['student_name']); ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Student Email:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($certificate_data['email']); ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Course Name:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($certificate_data['course_name']); ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Batch Code:</span>
                        <span class="detail-value"><?php echo $certificate_data['batch_code'] ? htmlspecialchars($certificate_data['batch_code']) : 'N/A'; ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Certificate Code:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($certificate_data['certificate_code']); ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Issue Date:</span>
                        <span class="detail-value"><?php echo date('d M Y', strtotime($certificate_data['issue_date'])); ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Internship Period:</span>
                        <span class="detail-value"><?php echo $course_start_formatted; ?> - <?php echo $course_end_formatted; ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
// Modal Functions
function openModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
    document.body.style.overflow = 'auto';
}

function closeCertificateModal() {
    const url = new URL(window.location.href);
    url.searchParams.delete('view');
    window.history.replaceState({}, '', url);
    document.getElementById('certificateModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

function viewCertificate(certId) {
    window.location.href = 'certificates.php?view=' + certId;
}

function loadBatchesAndStudents(courseId) {
    if (!courseId) {
        document.getElementById('batchSelect').innerHTML = '<option value="">First select a course</option>';
        document.getElementById('studentSelect').innerHTML = '<option value="">First select a batch</option>';
        return;
    }
    
    document.getElementById('studentSelect').innerHTML = '<option value="">First select a batch</option>';
    
    fetch('get_batches.php?course_id=' + courseId)
        .then(response => response.text())
        .then(data => {
            document.getElementById('batchSelect').innerHTML = data;
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('batchSelect').innerHTML = '<option value="">Error loading batches</option>';
        });
}

function loadStudentsByBatch(batchId) {
    if (!batchId || batchId === '0') {
        document.getElementById('studentSelect').innerHTML = '<option value="">Select a batch first</option>';
        return;
    }
    
    fetch('get_batch_students.php?batch_id=' + batchId)
        .then(response => response.text())
        .then(data => {
            document.getElementById('studentSelect').innerHTML = data;
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('studentSelect').innerHTML = '<option value="">Error loading students</option>';
        });
}

// Print Certificate - Landscape
function printCertificate() {
    const certificateContent = document.querySelector('.certificate-paper').cloneNode(true);
    const printWindow = window.open('', '_blank');
    
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Certificate - <?php echo isset($certificate_data) ? htmlspecialchars($certificate_data['certificate_code']) : ''; ?></title>
            <style>
                @page {
                    size: landscape;
                    margin: 0cm;
                }
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }
                body { 
                    margin: 0; 
                    padding:0px; 
                    background: white;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 100vh;
                }
                .certificate-paper {
                    max-width: 1100px;
                    width: 100%;
                    background: #ffffff;
                    box-shadow: none;
                    position: relative;
                }
                .certificate-inner {
                    position: relative;
                    width: 100%;
                    padding: 32px 40px 36px 40px;
                    display: flex;
                    flex-direction: column;
                    background: white;
                }
                .double-border {
                    position: absolute;
                    top: 14px;
                    left: 14px;
                    right: 14px;
                    bottom: 14px;
                    pointer-events: none;
                    z-index: 2;
                }
                .outer-border {
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    border: 2.5px solid #1a3e50;
                }
                .inner-border {
                    position: absolute;
                    top: 8px;
                    left: 8px;
                    right: 8px;
                    bottom: 8px;
                    border: 1px solid #c7a03a;
                }
                .triangle-left-top {
                    position: absolute;
                    top: 14px;
                    left: 14px;
                    width: 200px;
                    height: 500px;
                    border-style: solid;
                    border-width: 35px 35px 0 0;
                    border-color: #1f2858 transparent transparent transparent;
                    z-index: 5;
                    pointer-events: none;
                }
                .triangle-right-bottom {
                    position: absolute;
                    bottom: 14px;
                    right: 14px;
                    width: 200px;
                    height: 0;
                    border-style: solid;
                    border-width: 0 0 35px 35px;
                    border-color: transparent transparent #1f2858 transparent;
                    z-index: 3;
                    pointer-events: none;
                }
                .content { position: relative; z-index: 5; }
                .cert-id-top { text-align: right; font-size: 13px; font-weight: 500; color: #4a6f7e; display: inline-block; align-self: flex-start; padding: 6px 14px; border-radius: 30px; margin-bottom: 16px; margin-left:800px;}
                .title-section { text-align: center; margin:0; margin-top:20px; }
                .main-title { font-size: 52px; font-weight: 800; letter-spacing: 5px; color: #1a3e50; text-transform: uppercase; }
                .subtitle { font-size: 16px; font-weight: 500; color: #6b7f8c; letter-spacing: 3px; text-transform: uppercase; }
                .student-name-section { text-align: center; margin: 18px 0; font-family: Georgia, "Times New Roman", serif;}
                .name-highlight {  border-bottom: 2px solid #1f2858; padding-left: 24px; width: 80%; margin: 0 auto; }
                .student-fullname { font-size: 40px; font-weight: 600; color: #1a3e50; text-transform: uppercase; font-family: 'Cabin', Sans-Serif;}
                .completion-text { text-align: center; font-size: 20px; line-height: 1.6;font-weight:500; color: #2c3f4c; margin: 12px 0;
                
                    
                }
                .domain-highlight { font-weight: 800; color: #1a3e50; font-size:25px; 
                                font-family: 'Inter', sans-serif;
                                

                }
                .duration-text { font-weight: 600; padding: 2px 8px; border-radius: 20px; }
                .appreciation { text-align: center; max-width: 90%; font-size: 14px; line-height: 1.55; 
                font-size:20px;
                margin-left:70px;
                    
                }
                .bottom-row { display: flex; justify-content: space-between; align-items: flex-start; margin-top: 18px; gap: 24px; flex-wrap: wrap; }
                .signarea{ display : flex;
                    margin-left:350px;
                    gap :80px;
                    text-align:center;
                }
               
                .qr-box { width: 100px; height: 105px; background: #f8fafc; border: 1.5px solid #dce5ec; display: flex; flex-direction: column; align-items: center; justify-content: center; border-radius: 10px; margin-left:100px; position:absolute;
                    text-align:center;
                }
                .qr-img { width: 78px; height: 78px; object-fit: contain; 
                margin-top:5px;}
                .qr-label { font-size: 8px; margin-top: 6px; color: #5f7d8c; 
                    text-align:center;
                }
                .signature-area { text-align: center; min-width: 200px; flex: 1; margin-right:350px;}
                .signature-line { border-bottom: 1.5px solid #1a3e50; width: 100px; margin: 0 auto 6px auto; }
                .signature-label { font-size: 13px; font-weight: 600; color: #3e5e6e; letter-spacing: 1px; text-transform: uppercase; }
                .partner-logos { display: flex; gap: 24px;  margin-left:550px; position:absolute; 
                    margin-top:25px;
                }
                        .certified{

            position: absolute;
        }
        .certified img{
            margin-left: 850px;
            margin-top: 90px;
            position: absolute;
            height: 120px;
            
        }
        
        
        
        .img_manager{
        width:50px;
        height:50px;
         margin-top:20px; 
            
        }
        
         
        .img_founder{
        width:70px;
        height:70px;
            
            
        }
        
        
                .logo-box { width: 85px; height: 80px; border-radius: 10px; display: flex; flex-direction: column; align-items: center; justify-content: center; margin-left:250px;}
                .logo-icon { font-size: 32px; color: #1a3e50; }
                .logo-caption { font-size: 9px; font-weight: 600; color: #6f8ea0; text-transform: uppercase; }
                .footer-info { display: flex; margin-top: 20px; padding-top: 12px; border-top: 1px solid #e2e8f0; font-size: 18px; color: #5f7f8c;
                
                    margin-left:20px;
                }
                .footer-website{ margin-left:200px; font-size:18px;}
                @media print {
                    body { margin: 0; padding: 0; }
                    .certificate-paper { margin: 0; }
                }
                
                .n{
                    
                    margin-left:300px;
                }
                
            </style>
        </head>
        <body>
            <div class="certificate-paper">
                ${certificateContent.innerHTML}
            </div>
            <script>
                window.onload = function() {
                    window.print();
                    setTimeout(function() { window.close(); }, 1000);
                };
            <\/script>
        </body>
        </html>
    `);
    printWindow.document.close();
}

function shareCertificate() {
    if (navigator.share) {
        navigator.share({
            title: 'Certificate - <?php echo isset($certificate_data) ? htmlspecialchars($certificate_data['course_name']) : "Course Certificate"; ?>',
            text: 'Check out my certificate from CodexLabz!',
            url: window.location.href
        }).catch((error) => console.log('Error sharing:', error));
    } else {
        navigator.clipboard.writeText(window.location.href)
            .then(() => alert('Certificate link copied to clipboard!'))
            .catch(() => prompt('Copy this link to share:', window.location.href));
    }
}

function showQRInfo() {
    alert('Scan this QR code to verify the certificate authenticity online.');
}

// Close modal on escape key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (modal.style.display === 'block') {
                if (modal.id === 'certificateModal') {
                    closeCertificateModal();
                } else {
                    closeModal(modal.id);
                }
            }
        });
    }
});

// Close modal when clicking outside
window.onclick = function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target === modal) {
            if (modal.id === 'certificateModal') {
                closeCertificateModal();
            } else {
                closeModal(modal.id);
            }
        }
    });
};

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('generateCertForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            const courseSelect = document.getElementById('courseSelect');
            const batchSelect = document.getElementById('batchSelect');
            const studentSelect = document.getElementById('studentSelect');
            
            if (!courseSelect.value) {
                alert('Please select a course');
                e.preventDefault();
            } else if (!batchSelect.value || batchSelect.value === '0') {
                alert('Please select a batch');
                e.preventDefault();
            } else if (!studentSelect.value) {
                alert('Please select a student');
                e.preventDefault();
            }
        });
    }
});
</script>

<?php 
$conn->close();
require_once 'footer.php'; 
?>