<?php
require_once '../config/database.php';

$conn = getConnection();

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

if ($search !== '' && strlen($search) >= 2) {

    $sql = "SELECT id, name, email
            FROM students
            WHERE name LIKE ? OR email LIKE ?
            ORDER BY name
            LIMIT 10";

    $stmt = $conn->prepare($sql);
    $searchTerm = "%{$search}%";
    $stmt->bind_param("ss", $searchTerm, $searchTerm);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($student = $result->fetch_assoc()) {
            echo '<div class="search-result-item" data-id="' . (int)$student['id'] . '">';
            echo '<span class="student-name">' . htmlspecialchars($student['name']) . '</span>';
            echo '<span class="student-email">' . htmlspecialchars($student['email']) . '</span>';
            echo '</div>';
        }
    } else {
        echo '<div class="no-result">No students found</div>';
    }

    $stmt->close();
} else {
    echo '<div class="type-msg">Type at least 2 characters</div>';
}

$conn->close();
?>
