<?php
require_once 'header.php';

$conn = getConnection();
$message = '';

// Add Course
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_course'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $description = $conn->real_escape_string($_POST['description']);
    $course_fee = floatval($_POST['course_fee']);
    
    $sql = "INSERT INTO courses (name, description, course_fee) 
            VALUES ('$name', '$description', $course_fee)";
    
    if ($conn->query($sql)) {
        $message = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Course added successfully!</div>';
        echo '<script>window.location.href="courses.php";</script>';
        exit();
    } else {
        $message = '<div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> Error: ' . $conn->error . '</div>';
    }
}

// Update Course
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_course'])) {
    $id = intval($_POST['course_id']);
    $name = $conn->real_escape_string($_POST['name']);
    $description = $conn->real_escape_string($_POST['description']);
    $course_fee = floatval($_POST['course_fee']);
    
    $sql = "UPDATE courses SET 
            name = '$name',
            description = '$description',
            course_fee = $course_fee
            WHERE id = $id";
    
    if ($conn->query($sql)) {
        $message = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Course updated successfully!</div>';
        echo '<script>window.location.href="courses.php";</script>';
        exit();
    } else {
        $message = '<div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> Error: ' . $conn->error . '</div>';
    }
}

// Delete Course
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM courses WHERE id = $id");
    $message = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Course deleted successfully!</div>';
    echo '<script>window.location.href="courses.php";</script>';
    exit();
}

// Get courses
$courses = $conn->query("SELECT * FROM courses ORDER BY id DESC");
$total_courses = $courses->num_rows;

// Calculate total fees
$total_fees_result = $conn->query("SELECT SUM(course_fee) as total_fees FROM courses");
$total_fees = $total_fees_result->fetch_assoc()['total_fees'] ?? 0;
?>

<style>
/* Global Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f5f7fa;
    color: #333;
}

.container-fluid {
    padding: 20px;
}

/* Alerts */
.alert {
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
    animation: slideIn 0.3s ease;
}

.alert-success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.alert-error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

@keyframes slideIn {
    from { transform: translateY(-10px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

/* Card Styles */
.card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    overflow: hidden;
    margin-bottom: 30px;
}

.card-header {
    padding: 25px;
    background: linear-gradient(135deg, #2196F3 0%, #1976D2 100%);
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
}

.card-header h3 {
    font-size: 24px;
    display: flex;
    align-items: center;
    color: white;
    gap: 10px;
    margin: 0;
}

/* Buttons */
.btn-primary, .btn-secondary, .btn-success, .btn-danger, .btn-edit {
    padding: 10px 20px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
    text-decoration: none;
}

.btn-primary {
    background: #2196F3;
    color: white;
}

.btn-primary:hover {
    background: #1976D2;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(33, 150, 243, 0.3);
}

.btn-success {
    background: #28a745;
    color: white;
}

.btn-success:hover {
    background: #218838;
    transform: translateY(-2px);
}

.btn-danger {
    background: #dc3545;
    color: white;
}

.btn-danger:hover {
    background: #c82333;
    transform: translateY(-2px);
}

.btn-secondary {
    background: #6c757d;
    color: white;
}

.btn-secondary:hover {
    background: #5a6268;
}

.btn-edit {
    background: #ffc107;
    color: #212529;
}

.btn-edit:hover {
    background: #e0a800;
}

.btn-sm {
    padding: 6px 12px;
    font-size: 12px;
}

/* Course row clickable */
.course-row {
    cursor: pointer;
    transition: background 0.2s;
}

.course-row:hover {
    background: #f0f2f5 !important;
}

/* Table Styles */
.table-container {
    overflow-x: auto;
    border-radius: 8px;
    border: 1px solid #e0e0e0;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 1000px;
}

thead {
    background: #f8f9fa;
}

th {
    padding: 18px 15px;
    text-align: left;
    font-weight: 600;
    color: #495057;
    border-bottom: 2px solid #dee2e6;
}

td {
    padding: 16px 15px;
    border-bottom: 1px solid #e0e0e0;
    vertical-align: middle;
}

/* Badge Styles */
.badge {
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 500;
}

.badge-success {
    background: #d4edda;
    color: #155724;
}

/* Action Buttons */
.action-buttons {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
}

/* Modal Styles */
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.7);
    z-index: 1000;
    overflow-y: auto;
    padding: 20px;
}

.modal-content {
    background: white;
    border-radius: 12px;
    margin: 50px auto;
    max-width: 700px;
    animation: modalSlideIn 0.3s ease;
}

@keyframes modalSlideIn {
    from { transform: translateY(-50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

.modal-header {
    padding: 25px;
    border-bottom: 1px solid #e0e0e0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 {
    color: #2c3e50;
    font-size: 22px;
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0;
}

.close-modal {
    background: none;
    border: none;
    font-size: 28px;
    color: #7f8c8d;
    cursor: pointer;
    transition: color 0.3s;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
}

.close-modal:hover {
    color: #e74c3c;
    background: #f9f9f9;
}

/* Course Detail Modal */
.course-detail-modal .modal-content {
    max-width: 700px;
}

.course-profile-header {
    background: linear-gradient(135deg, #2196F3 0%, #1976D2 100%);
    color: white;
    padding: 30px;
    border-radius: 8px 8px 0 0;
    margin: -25px -25px 20px -25px;
    position: relative;
    text-align: center;
}

.course-avatar-large {
    width: 80px;
    height: 80px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 36px;
    color: #2196F3;
    margin: 0 auto 15px auto;
    border: 3px solid rgba(255,255,255,0.3);
}

.edit-mode-btn {
    position: absolute;
    top: 20px;
    right: 20px;
    background: rgba(255,255,255,0.2);
    color: white;
    border: 1px solid rgba(255,255,255,0.5);
    padding: 8px 15px;
    border-radius: 20px;
    cursor: pointer;
    transition: all 0.3s;
    font-size: 14px;
}

.edit-mode-btn:hover {
    background: rgba(255,255,255,0.3);
}

.detail-section {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
}

.detail-section h4 {
    margin: 0 0 15px 0;
    color: #2c3e50;
    display: flex;
    align-items: center;
    gap: 10px;
    border-bottom: 2px solid #dee2e6;
    padding-bottom: 10px;
}

.detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
}

.detail-item {
    display: flex;
    flex-direction: column;
}

.detail-label {
    font-size: 12px;
    color: #7f8c8d;
    margin-bottom: 3px;
}

.detail-value {
    font-weight: 500;
    color: #2c3e50;
}

.detail-value.full-width {
    grid-column: span 2;
}

/* Edit Form Styles */
.edit-form-section {
    background: white;
    border-radius: 8px;
    padding: 20px;
    margin-top: 20px;
    border: 2px solid #2196F3;
    display: none;
}

.edit-form-section.show {
    display: block;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.edit-form-section h4 {
    color: #2196F3;
    margin-bottom: 20px;
}

/* Form Styles */
.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    color: #2c3e50;
}

.form-control {
    width: 100%;
    padding: 12px 15px;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 14px;
    transition: border 0.3s;
}

.form-control:focus {
    outline: none;
    border-color: #2196F3;
    box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.1);
}

textarea.form-control {
    resize: vertical;
    min-height: 80px;
}

/* Modal Actions */
.modal-actions {
    display: flex;
    gap: 10px;
    justify-content: flex-end;
    margin-top: 20px;
}

/* No Data State */
.no-data {
    text-align: center;
    padding: 60px 20px;
    color: #7f8c8d;
}

.no-data i {
    font-size: 64px;
    margin-bottom: 20px;
    opacity: 0.3;
}

.no-data h3 {
    margin-bottom: 10px;
    color: #95a5a6;
}
</style>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-book"></i> Courses Management</h3>
            <button class="btn-primary" onclick="openModal('addCourseModal')">
                <i class="fas fa-plus-circle"></i> Add Course
            </button>
        </div>
        
        <div style="padding: 20px;">
            <?php echo $message; ?>
            
            <!-- Stats -->
            <div style="display: flex; gap: 15px; margin-bottom: 20px; flex-wrap: wrap;">
                <div style="background: #f8f9fa; padding: 10px 20px; border-radius: 6px;">
                    <small style="color: #7f8c8d;">Total Courses</small>
                    <h4 style="margin: 5px 0; color: #2c3e50;"><?php echo $total_courses; ?></h4>
                </div>
                <div style="background: #f8f9fa; padding: 10px 20px; border-radius: 6px;">
                    <small style="color: #7f8c8d;">Total Course Fees</small>
                    <h4 style="margin: 5px 0; color: #2E7D32;">
                        <i class="fas fa-rupee-sign" style="font-size: 14px;"></i> <?php echo number_format($total_fees, 2); ?>
                    </h4>
                </div>
            </div>
            
            <!-- Courses Table -->
            <?php if($total_courses > 0): ?>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Course Name</th>
                            <th>Description</th>
                            <th>Course Fee</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $courses->fetch_assoc()): ?>
                        <tr class="course-row" onclick="viewCourseDetails(<?php echo $row['id']; ?>, <?php echo htmlspecialchars(json_encode($row)); ?>)">
                            <td><?php echo $row['id']; ?></td>
                            <td>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div style="width: 40px; height: 40px; background: #2196F3; 
                                          border-radius: 8px; display: flex; align-items: center; justify-content: center; color: white;">
                                        <i class="fas fa-book"></i>
                                    </div>
                                    <div>
                                        <span style="font-weight: 500;"><?php echo htmlspecialchars($row['name']); ?></span>
                                        <?php if($row['course_fee'] > 0): ?>
                                        <div style="font-size: 12px; color: #7f8c8d;">
                                            <i class="fas fa-rupee-sign"></i> <?php echo number_format($row['course_fee'], 2); ?>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo htmlspecialchars(substr($row['description'], 0, 50)) . '...'; ?></td>
                            <td>
                                <span style="font-weight: bold; color: #2E7D32;">
                                    <i class="fas fa-rupee-sign"></i> <?php echo number_format($row['course_fee'], 2); ?>
                                </span>
                            </td>
                            <td onclick="event.stopPropagation();">
                                <div class="action-buttons">
                                    <a href="batches.php?course_id=<?php echo $row['id']; ?>" 
                                       class="btn-sm btn-primary">
                                        <i class="fas fa-layer-group"></i> Batches
                                    </a>
                                    
                                    <a href="?delete=<?php echo $row['id']; ?>" 
                                       class="btn-sm btn-danger" 
                                       onclick="return confirm('Are you sure you want to delete this course? All associated batches will also be deleted.')">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="no-data">
                <i class="fas fa-book"></i>
                <h3>No Courses Found</h3>
                <p>Add your first course to get started</p>
                <button class="btn-primary" onclick="openModal('addCourseModal')" style="margin-top: 20px;">
                    <i class="fas fa-plus-circle"></i> Add First Course
                </button>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Add Course Modal -->
<div id="addCourseModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-plus-circle"></i> Add New Course</h3>
            <button class="close-modal" onclick="closeModal('addCourseModal')">&times;</button>
        </div>
        <form method="POST" id="courseForm">
            <div class="form-group">
                <label>Course Name *</label>
                <input type="text" name="name" class="form-control" placeholder="Enter course name" required>
            </div>
            
            <div class="form-group">
                <label>Description *</label>
                <textarea name="description" class="form-control" rows="3" placeholder="Enter course description" required></textarea>
            </div>
            
            <div class="form-group">
                <label>Course Fee *</label>
                <div style="position: relative;">
                    <span style="position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #7f8c8d; font-weight: bold;">₹</span>
                    <input type="number" name="course_fee" class="form-control" 
                           placeholder="Enter course fee" step="0.01" min="0" required
                           style="padding-left: 35px;">
                </div>
                <small style="color: #7f8c8d;">This fee will be required when students enroll in batches of this course</small>
            </div>
            
            <div class="modal-footer" style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                <button type="button" class="btn-secondary" onclick="closeModal('addCourseModal')">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="submit" name="add_course" class="btn-primary">
                    <i class="fas fa-save"></i> Add Course
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Course Details Modal (View & Edit in One) -->
<div id="courseDetailModal" class="modal course-detail-modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-book"></i> Course Details</h3>
            <button class="close-modal" onclick="closeModal('courseDetailModal')">&times;</button>
        </div>
        
        <!-- This will be populated with course data -->
        <div id="courseDetailContent" style="padding: 20px; max-height: 70vh; overflow-y: auto;">
            <div style="text-align: center; padding: 40px;">
                <i class="fas fa-spinner fa-spin" style="font-size: 32px; color: #2196F3;"></i>
                <p style="margin-top: 15px; color: #6c757d;">Loading course details...</p>
            </div>
        </div>
    </div>
</div>

<script>
// Global variable to store current course data
let currentCourseData = null;

// View Course Details in Modal
function viewCourseDetails(courseId, courseData) {
    const modal = document.getElementById('courseDetailModal');
    const content = document.getElementById('courseDetailContent');
    
    // Store current course data
    currentCourseData = courseData;
    
    // Display course details immediately with the passed data
    displayCourseDetails(courseId, courseData);
    
    modal.style.display = 'block';
    // Page remains scrollable
}

// Display course details with edit form
function displayCourseDetails(courseId, course) {
    const content = document.getElementById('courseDetailContent');
    const initial = course.name.charAt(0).toUpperCase();
    
    let html = `
        <!-- Course Profile Header -->
        <div class="course-profile-header">
            <button class="edit-mode-btn" onclick="toggleEditMode()" id="editModeBtn">
                <i class="fas fa-edit"></i> Edit Course
            </button>
            <div class="course-avatar-large">
                <i class="fas fa-book"></i>
            </div>
            <h2 style="margin: 10px 0 5px 0;">${escapeHtml(course.name)}</h2>
            <div style="display: flex; gap: 10px; justify-content: center; flex-wrap: wrap;">
                <span style="background: rgba(255,255,255,0.2); padding: 4px 12px; border-radius: 20px; font-size: 13px;">
                    <i class="fas fa-rupee-sign"></i> ${parseFloat(course.course_fee).toFixed(2)}
                </span>
            </div>
        </div>
        
        <!-- View Mode (Default) -->
        <div id="viewModeContent">
            <!-- Course Information -->
            <div class="detail-section">
                <h4><i class="fas fa-info-circle"></i> Course Information</h4>
                <div class="detail-grid">
                    <div class="detail-item">
                        <span class="detail-label">Course Name</span>
                        <span class="detail-value">${escapeHtml(course.name)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Course Fee</span>
                        <span class="detail-value"><i class="fas fa-rupee-sign"></i> ${parseFloat(course.course_fee).toFixed(2)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Course ID</span>
                        <span class="detail-value">${course.id}</span>
                    </div>
                    <div class="detail-item full-width">
                        <span class="detail-label">Description</span>
                        <span class="detail-value">${escapeHtml(course.description)}</span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Edit Mode (Hidden by Default) -->
        <div id="editModeContent" class="edit-form-section">
            <h4><i class="fas fa-edit"></i> Edit Course</h4>
            <form method="POST" action="" onsubmit="return validateEditForm()">
                <input type="hidden" name="course_id" value="${course.id}">
                <input type="hidden" name="update_course" value="1">
                
                <div class="form-group">
                    <label>Course Name *</label>
                    <input type="text" name="name" class="form-control" value="${escapeHtml(course.name)}" required>
                </div>
                
                <div class="form-group">
                    <label>Description *</label>
                    <textarea name="description" class="form-control" rows="3" required>${escapeHtml(course.description)}</textarea>
                </div>
                
                <div class="form-group">
                    <label>Course Fee *</label>
                    <div style="position: relative;">
                        <span style="position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #7f8c8d; font-weight: bold;">₹</span>
                        <input type="number" name="course_fee" class="form-control" 
                               value="${parseFloat(course.course_fee).toFixed(2)}" step="0.01" min="0" required
                               style="padding-left: 35px;">
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn-secondary" onclick="cancelEdit()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn-success">
                        <i class="fas fa-save"></i> UPDATE
                    </button>
                </div>
            </form>
        </div>
        
        <!-- Modal Actions -->
        <div class="modal-actions">
            <a href="batches.php?course_id=${course.id}" class="btn-sm btn-primary">
                <i class="fas fa-layer-group"></i> View Batches
            </a>
            <button onclick="closeModal('courseDetailModal')" class="btn-sm btn-secondary">
                <i class="fas fa-times"></i> Close
            </button>
        </div>
    `;
    
    content.innerHTML = html;
}

// Toggle between view and edit modes
function toggleEditMode() {
    const viewMode = document.getElementById('viewModeContent');
    const editMode = document.getElementById('editModeContent');
    const editBtn = document.getElementById('editModeBtn');
    
    if (viewMode && editMode) {
        if (viewMode.style.display === 'none' || viewMode.style.display === '') {
            // Switch to view mode
            viewMode.style.display = 'block';
            editMode.style.display = 'none';
            editBtn.innerHTML = '<i class="fas fa-edit"></i> Edit Course';
        } else {
            // Switch to edit mode
            viewMode.style.display = 'none';
            editMode.style.display = 'block';
            editBtn.innerHTML = '<i class="fas fa-eye"></i> View Details';
        }
    }
}

// Cancel edit and return to view mode
function cancelEdit() {
    const viewMode = document.getElementById('viewModeContent');
    const editMode = document.getElementById('editModeContent');
    const editBtn = document.getElementById('editModeBtn');
    
    if (viewMode && editMode) {
        viewMode.style.display = 'block';
        editMode.style.display = 'none';
        editBtn.innerHTML = '<i class="fas fa-edit"></i> Edit Course';
    }
}

// Validate edit form
function validateEditForm() {
    const editForm = document.querySelector('#editModeContent form');
    if (!editForm) {
        alert('Form not found');
        return false;
    }
    
    const nameInput = editForm.querySelector('input[name="name"]');
    const descInput = editForm.querySelector('textarea[name="description"]');
    const feeInput = editForm.querySelector('input[name="course_fee"]');
    
    if (!nameInput || !descInput || !feeInput) {
        alert('Form fields not found');
        return false;
    }
    
    const name = nameInput.value.trim();
    const description = descInput.value.trim();
    const fee = parseFloat(feeInput.value);
    
    if (name === '') {
        alert('Please enter course name');
        nameInput.focus();
        return false;
    }
    
    if (description === '') {
        alert('Please enter course description');
        descInput.focus();
        return false;
    }
    
    if (isNaN(fee) || fee < 0) {
        alert('Please enter a valid course fee');
        feeInput.focus();
        return false;
    }
    
    return true;
}

// Helper function to escape HTML
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Modal Functions
function openModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
    // Page remains scrollable
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
    if (modalId === 'addCourseModal') {
        document.getElementById('courseForm').reset();
    }
}

// Close modal when clicking outside
window.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
});

// Confirm delete function
function confirmDelete(message) {
    return confirm(message);
}
</script>

<?php 
$conn->close();
require_once 'footer.php'; 
?>