<?php
require_once 'header.php';

$conn = getConnection();
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    $admin_id = $_SESSION['admin_id'];
    
    // Get current password
    $result = $conn->query("SELECT password FROM admin WHERE id = $admin_id");
    $admin = $result->fetch_assoc();
    
    if (password_verify($current_password, $admin['password'])) {
        if ($new_password == $confirm_password) {
            if (strlen($new_password) < 6) {
                $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Password must be at least 6 characters long!</div>';
            } else {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $conn->query("UPDATE admin SET password = '$hashed_password' WHERE id = $admin_id");
                $message = '<div class="alert-success"><i class="fas fa-check-circle"></i> Password changed successfully!</div>';
            }
        } else {
            $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> New passwords do not match!</div>';
        }
    } else {
        $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Current password is incorrect!</div>';
    }
}
?>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-key"></i> Change Password</h3>
    </div>
    
    <div style="padding: 20px; max-width: 500px; margin: 0 auto;">
        <?php echo $message; ?>
        
        <form method="POST">
            <div class="form-group">
                <label>Current Password *</label>
                <div style="position: relative;">
                    <input type="password" name="current_password" id="current_password" 
                           class="form-control" placeholder="Enter current password" required>
                    <button type="button" onclick="togglePassword('current_password')" 
                            style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); 
                                   background: none; border: none; cursor: pointer; color: #7f8c8d;">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>
            
            <div class="form-group">
                <label>New Password *</label>
                <div style="position: relative;">
                    <input type="password" name="new_password" id="new_password" 
                           class="form-control" placeholder="Enter new password" required>
                    <button type="button" onclick="togglePassword('new_password')" 
                            style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); 
                                   background: none; border: none; cursor: pointer; color: #7f8c8d;">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
                <small style="color: #7f8c8d;">Password must be at least 6 characters long</small>
            </div>
            
            <div class="form-group">
                <label>Confirm New Password *</label>
                <div style="position: relative;">
                    <input type="password" name="confirm_password" id="confirm_password" 
                           class="form-control" placeholder="Confirm new password" required>
                    <button type="button" onclick="togglePassword('confirm_password')" 
                            style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); 
                                   background: none; border: none; cursor: pointer; color: #7f8c8d;">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>
            
            <div class="modal-footer" style="border: none; padding: 0; margin-top: 30px;">
                <button type="submit" class="btn-primary">
                    <i class="fas fa-save"></i> Change Password
                </button>
            </div>
        </form>
    </div>
</div>

<?php 
$conn->close();
require_once 'footer.php'; 
?>