<?php
    require_once 'header.php';

    $conn = getConnection();
    $message = '';

    // First, ensure required database tables exist
    checkFeeTables($conn);

    function checkFeeTables($conn) {
        // Check if batch_fees table exists
        $check = $conn->query("SHOW TABLES LIKE 'batch_fees'");
        if ($check->num_rows == 0) {
            // Create batch_fees table
            $conn->query("CREATE TABLE IF NOT EXISTS batch_fees (
                id INT PRIMARY KEY AUTO_INCREMENT,
                batch_id INT NOT NULL,
                student_id INT NOT NULL,
                total_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
                paid_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
                remaining_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
                last_payment_date DATE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE CASCADE,
                FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
            )");
        }
        
        // Check if fee_payments table exists
        $check = $conn->query("SHOW TABLES LIKE 'fee_payments'");
        if ($check->num_rows == 0) {
            // Create fee_payments table
            $conn->query("CREATE TABLE IF NOT EXISTS fee_payments (
                id INT PRIMARY KEY AUTO_INCREMENT,
                batch_id INT NOT NULL,
                student_id INT NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                payment_date DATE NOT NULL,
                payment_method ENUM('cash', 'bank_transfer', 'cheque', 'card', 'online') NOT NULL,
                reference_no VARCHAR(100),
                notes TEXT,
                receipt_no VARCHAR(50) UNIQUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE CASCADE,
                FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
            )");
            
            // Add receipt_no column if not exists (for existing tables)
            $check_column = $conn->query("SHOW COLUMNS FROM fee_payments LIKE 'receipt_no'");
            if ($check_column->num_rows == 0) {
                $conn->query("ALTER TABLE fee_payments ADD COLUMN receipt_no VARCHAR(50) UNIQUE");
            }
        } else {
            // Check if receipt_no column exists in existing table
            $check_column = $conn->query("SHOW COLUMNS FROM fee_payments LIKE 'receipt_no'");
            if ($check_column->num_rows == 0) {
                $conn->query("ALTER TABLE fee_payments ADD COLUMN receipt_no VARCHAR(50) UNIQUE");
            }
        }
        
        // Add course_fee column to batches table if not exists
        $check = $conn->query("SHOW COLUMNS FROM batches LIKE 'course_fee'");
        if ($check->num_rows == 0) {
            $conn->query("ALTER TABLE batches ADD COLUMN course_fee DECIMAL(10,2) DEFAULT 0");
        }
        
        // Add status column to batches table if not exists
        $check = $conn->query("SHOW COLUMNS FROM batches LIKE 'status'");
        if ($check->num_rows == 0) {
            $conn->query("ALTER TABLE batches ADD COLUMN status ENUM('active', 'completed') DEFAULT 'active'");
        }
    }

    // Function to generate unique receipt number
    function generateReceiptNo($conn) {
        $year = date('Y');
        $month = date('m');
        $prefix = "RCP-{$year}{$month}-";
        
        // Get the last receipt number for this month
        $result = $conn->query("SELECT receipt_no FROM fee_payments 
                                WHERE receipt_no LIKE '{$prefix}%' 
                                ORDER BY id DESC LIMIT 1");
        
        if ($result->num_rows > 0) {
            $last_receipt = $result->fetch_assoc()['receipt_no'];
            $last_number = intval(substr($last_receipt, -4));
            $new_number = str_pad($last_number + 1, 4, '0', STR_PAD_LEFT);
        } else {
            $new_number = '0001';
        }
        
        return $prefix . $new_number;
    }

    // Get selected course from URL
    $selected_course = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;

    // Add Batch
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_batch'])) {
        $course_id = intval($_POST['course_id']);
        $batch_name = $conn->real_escape_string($_POST['batch_name']);
        $batch_code = $conn->real_escape_string($_POST['batch_code']);
        $student_limit = intval($_POST['student_limit']);
        $start_date = $conn->real_escape_string($_POST['start_date']);
        $end_date = $conn->real_escape_string($_POST['end_date']);
        
        // Get course fee
        $course_result = $conn->query("SELECT course_fee FROM courses WHERE id = $course_id");
        if ($course_result->num_rows > 0) {
            $course = $course_result->fetch_assoc();
            $course_fee = $course['course_fee'] ?? 0;
            
            // Check if batch code already exists
            $check_code = $conn->query("SELECT id FROM batches WHERE batch_code = '$batch_code'");
            if ($check_code->num_rows > 0) {
                $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Batch code already exists!</div>';
            } else {
                $sql = "INSERT INTO batches (course_id, batch_name, batch_code, start_date, end_date, student_limit, course_fee, status) 
                        VALUES ($course_id, '$batch_name', '$batch_code', '$start_date', '$end_date', $student_limit, $course_fee, 'active')";
                
                if ($conn->query($sql)) {
                    $message = '<div class="alert-success"><i class="fas fa-check-circle"></i> Batch created successfully!</div>';
                    echo '<script>setTimeout(function(){ window.location.href = "batches.php?course_id=' . $course_id . '"; }, 1500);</script>';
                } else {
                    $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Error: ' . $conn->error . '</div>';
                }
            }
        } else {
            $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Course not found!</div>';
        }
    }

    // Update Batch
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_batch'])) {
        $batch_id = intval($_POST['batch_id']);
        $batch_name = $conn->real_escape_string($_POST['batch_name']);
        $batch_code = $conn->real_escape_string($_POST['batch_code']);
        $student_limit = intval($_POST['student_limit']);
        $start_date = $conn->real_escape_string($_POST['start_date']);
        $end_date = $conn->real_escape_string($_POST['end_date']);
        
        // Get course_id for redirect
        $batch_info = $conn->query("SELECT course_id FROM batches WHERE id = $batch_id")->fetch_assoc();
        $redirect_course = $batch_info ? $batch_info['course_id'] : 0;
        
        // Check if batch code already exists for another batch
        $check_code = $conn->query("SELECT id FROM batches WHERE batch_code = '$batch_code' AND id != $batch_id");
        if ($check_code->num_rows > 0) {
            $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Batch code already exists!</div>';
        } else {
            $sql = "UPDATE batches SET 
                    batch_name = '$batch_name',
                    batch_code = '$batch_code',
                    student_limit = $student_limit,
                    start_date = '$start_date',
                    end_date = '$end_date'
                    WHERE id = $batch_id";
            
            if ($conn->query($sql)) {
                $message = '<div class="alert-success"><i class="fas fa-check-circle"></i> Batch updated successfully!</div>';
                echo '<script>setTimeout(function(){ window.location.href = "batches.php?course_id=' . $redirect_course . '"; }, 1500);</script>';
            } else {
                $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Error: ' . $conn->error . '</div>';
            }
        }
    }

    // Complete Batch
    if (isset($_GET['complete_batch'])) {
        $id = intval($_GET['complete_batch']);
        
        // Get course_id before completion for redirect
        $batch_info = $conn->query("SELECT course_id FROM batches WHERE id = $id")->fetch_assoc();
        $redirect_course = $batch_info ? $batch_info['course_id'] : 0;
        
        // Update batch status to completed
        if ($conn->query("UPDATE batches SET status = 'completed' WHERE id = $id")) {
            $message = '<div class="alert-success"><i class="fas fa-check-circle"></i> Batch marked as completed successfully!</div>';
        } else {
            $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Error: ' . $conn->error . '</div>';
        }
        
        echo '<script>setTimeout(function(){ window.location.href = "batches.php?course_id=' . $redirect_course . '"; }, 1500);</script>';
    }

    // Delete Batch
    if (isset($_GET['delete_batch'])) {
        $id = intval($_GET['delete_batch']);
        // Get course_id before deletion for redirect
        $course_info = $conn->query("SELECT course_id FROM batches WHERE id = $id")->fetch_assoc();
        $redirect_course = $course_info ? $course_info['course_id'] : 0;
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Delete from batch_students first (foreign key constraint)
            $conn->query("DELETE FROM batch_students WHERE batch_id = $id");
            // Delete from batch_fees
            $conn->query("DELETE FROM batch_fees WHERE batch_id = $id");
            // Delete from fee_payments
            $conn->query("DELETE FROM fee_payments WHERE batch_id = $id");
            // Then delete the batch
            if ($conn->query("DELETE FROM batches WHERE id = $id")) {
                $conn->commit();
                $message = '<div class="alert-success"><i class="fas fa-check-circle"></i> Batch deleted successfully!</div>';
                echo '<script>setTimeout(function(){ window.location.href = "batches.php?course_id=' . $redirect_course . '"; }, 1500);</script>';
            } else {
                throw new Exception($conn->error);
            }
        } catch (Exception $e) {
            $conn->rollback();
            $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Error: ' . $e->getMessage() . '</div>';
        }
    }

    // Add Student to Batch with Fee Options
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_student_to_batch'])) {
        $batch_id = intval($_POST['batch_id']);
        $student_id = intval($_POST['student_id']);
        $fee_option = isset($_POST['fee_option']) ? $conn->real_escape_string($_POST['fee_option']) : 'full_course';
        $custom_fee = isset($_POST['custom_fee']) ? floatval($_POST['custom_fee']) : 0;
        
        // Get course_id for redirect
        $batch_info = $conn->query("SELECT course_id, student_limit, course_fee FROM batches WHERE id = $batch_id")->fetch_assoc();
        $redirect_course = $batch_info ? $batch_info['course_id'] : 0;
        
        if ($batch_id > 0 && $student_id > 0) {
            // Get batch student limit, current count, and course fee
            $current_count = $conn->query("SELECT COUNT(*) as count FROM batch_students WHERE batch_id = $batch_id")->fetch_assoc()['count'];
            
            // Check if batch is full
            if ($batch_info['student_limit'] > 0 && $current_count >= $batch_info['student_limit']) {
                $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Batch is full! Student limit: ' . $batch_info['student_limit'] . '</div>';
            } else {
                // Check if student already in batch
                $check = $conn->query("SELECT id FROM batch_students WHERE batch_id = $batch_id AND student_id = $student_id");
                
                if ($check->num_rows > 0) {
                    $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Student already enrolled in this batch!</div>';
                } else {
                    // Determine fee amount based on option
                    $total_fee = $batch_info['course_fee'];
                    
                    if ($fee_option === 'no_fee') {
                        $total_fee = 0;
                        $paid_amount = 0;
                    } elseif ($fee_option === 'custom_fee' && $custom_fee > 0) {
                        $total_fee = $custom_fee;
                        $paid_amount = 0;
                    } elseif ($fee_option === 'partially_paid') {
                        // For partially paid, we need to check if initial_payment is provided
                        $initial_payment = isset($_POST['initial_payment']) ? floatval($_POST['initial_payment']) : 0;
                        if ($initial_payment > 0 && $initial_payment <= $batch_info['course_fee']) {
                            $paid_amount = $initial_payment;
                        } else {
                            $paid_amount = 0;
                        }
                    } else {
                        // Full course fee, not paid yet
                        $paid_amount = 0;
                    }
                    
                    $remaining_fee = $total_fee - $paid_amount;
                    
                    // Start transaction
                    $conn->begin_transaction();
                    
                    try {
                        // Add student to batch
                        $sql1 = "INSERT INTO batch_students (batch_id, student_id) VALUES ($batch_id, $student_id)";
                        if (!$conn->query($sql1)) {
                            throw new Exception("Error adding student to batch: " . $conn->error);
                        }
                        
                        // Initialize fee record
                        $sql2 = "INSERT INTO batch_fees (batch_id, student_id, total_fee, paid_amount, remaining_fee) 
                                VALUES ($batch_id, $student_id, $total_fee, $paid_amount, $remaining_fee)";
                        if (!$conn->query($sql2)) {
                            throw new Exception("Error creating fee record: " . $conn->error);
                        }
                        
                        // If there's an initial payment, record it
                        if ($paid_amount > 0) {
                            $payment_date = date('Y-m-d');
                            $payment_method = 'cash';
                            $receipt_no = generateReceiptNo($conn);
                            $reference_no = 'INIT-' . time();
                            
                            $sql3 = "INSERT INTO fee_payments 
                                    (batch_id, student_id, amount, payment_date, payment_method, reference_no, notes, receipt_no) 
                                    VALUES ($batch_id, $student_id, $paid_amount, '$payment_date', 
                                            '$payment_method', '$reference_no', 'Initial payment', '$receipt_no')";
                            if (!$conn->query($sql3)) {
                                throw new Exception("Error recording initial payment: " . $conn->error);
                            }
                        }
                        
                        $conn->commit();
                        $message = '<div class="alert-success"><i class="fas fa-check-circle"></i> Student added to batch successfully!</div>';
                        echo '<script>setTimeout(function(){ window.location.href = "batches.php?course_id=' . $redirect_course . '"; }, 1500);</script>';
                        
                    } catch (Exception $e) {
                        $conn->rollback();
                        $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> ' . $e->getMessage() . '</div>';
                    }
                }
            }
        } else {
            $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Please select both batch and student!</div>';
        }
    }

    // Add Fee Payment
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_fee_payment'])) {
        $batch_id = intval($_POST['batch_id']);
        $student_id = intval($_POST['student_id']);
        $payment_amount = floatval($_POST['payment_amount']);
        $payment_date = $conn->real_escape_string($_POST['payment_date']);
        $payment_method = $conn->real_escape_string($_POST['payment_method']);
        $reference_no = $conn->real_escape_string($_POST['reference_no']);
        $notes = $conn->real_escape_string($_POST['notes']);
        
        // Get course_id for redirect
        $batch_info = $conn->query("SELECT course_id FROM batches WHERE id = $batch_id")->fetch_assoc();
        $redirect_course = $batch_info ? $batch_info['course_id'] : 0;
        
        if ($payment_amount <= 0) {
            $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Payment amount must be greater than 0!</div>';
        } else {
            // Start transaction
            $conn->begin_transaction();
            
            try {
                // Get current fee status
                $fee_info = $conn->query("SELECT total_fee, paid_amount FROM batch_fees 
                                        WHERE batch_id = $batch_id AND student_id = $student_id")->fetch_assoc();
                
                if (!$fee_info) {
                    throw new Exception("Fee record not found!");
                }
                
                $new_paid_amount = $fee_info['paid_amount'] + $payment_amount;
                
                // Update batch_fees table
                $update_fee = $conn->query("UPDATE batch_fees SET 
                                        paid_amount = $new_paid_amount,
                                        remaining_fee = total_fee - $new_paid_amount,
                                        last_payment_date = '$payment_date'
                                        WHERE batch_id = $batch_id AND student_id = $student_id");
                
                if (!$update_fee) {
                    throw new Exception("Error updating fee: " . $conn->error);
                }
                
                // Generate receipt number
                $receipt_no = generateReceiptNo($conn);
                
                // Insert into fee_payments table
                $insert_payment = $conn->query("INSERT INTO fee_payments 
                                            (batch_id, student_id, amount, payment_date, payment_method, reference_no, notes, receipt_no) 
                                            VALUES ($batch_id, $student_id, $payment_amount, '$payment_date', 
                                                    '$payment_method', '$reference_no', '$notes', '$receipt_no')");
                
                if (!$insert_payment) {
                    throw new Exception("Error recording payment: " . $conn->error);
                }
                
                $conn->commit();
                $message = '<div class="alert-success"><i class="fas fa-check-circle"></i> Payment recorded successfully! Receipt No: ' . $receipt_no . '</div>';
                echo '<script>setTimeout(function(){ window.location.href = "batches.php?course_id=' . $redirect_course . '"; }, 1500);</script>';
                
            } catch (Exception $e) {
                $conn->rollback();
                $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> ' . $e->getMessage() . '</div>';
            }
        }
    }

    // View Receipt
    if (isset($_GET['view_receipt'])) {
        $payment_id = intval($_GET['view_receipt']);
        $payment = $conn->query("SELECT p.*, s.name as student_name, s.email, s.phone, s.address,
                                b.batch_name, b.batch_code, b.start_date, b.end_date, c.name as course_name,
                                bf.total_fee, bf.paid_amount as total_paid
                                FROM fee_payments p
                                JOIN students s ON p.student_id = s.id
                                JOIN batches b ON p.batch_id = b.id
                                JOIN courses c ON b.course_id = c.id
                                JOIN batch_fees bf ON bf.batch_id = p.batch_id AND bf.student_id = p.student_id
                                WHERE p.id = $payment_id")->fetch_assoc();
        
        if (!$payment) {
            $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Receipt not found!</div>';
        } else {
            // Display receipt in modal or new page
            ?>
            <div class="card" style="max-width: 800px; margin: 20px auto;">
                <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
                    <h3><i class="fas fa-receipt"></i> Payment Receipt</h3>
                    <div>
                        <button onclick="printReceipt()" class="btn-primary">
                            <i class="fas fa-print"></i> Print Receipt
                        </button>
                        <a href="batches.php?course_id=<?php echo $selected_course; ?>" class="btn-secondary">
                            <i class="fas fa-arrow-left"></i> Back
                        </a>
                    </div>
                </div>
                <div class="card-body" style="padding: 30px;" id="receipt-content">
                    <!-- Receipt Header -->
                    <div style="text-align: center; margin-bottom: 30px; border-bottom: 2px solid #007bff; padding-bottom: 20px;">
                        <h2 style="margin: 0; color: #007bff;">CodexLabz</h2>
                        <p style="margin: 5px 0; color: #666;">Atapadi, Pin - 415301</p>
                        <p style="margin: 5px 0; color: #666;">Phone: +91 7385284210 | Email: info@codexlabz.com</p>
                    </div>
                    
                    <!-- Receipt Info -->
                    <div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
                        <div>
                            <h4 style="margin: 0 0 10px 0; color: #333;">Receipt Details</h4>
                            <p><strong>Receipt No:</strong> <?php echo $payment['receipt_no']; ?></p>
                            <p><strong>Date:</strong> <?php echo date('d M Y', strtotime($payment['payment_date'])); ?></p>
                            <p><strong>Payment Method:</strong> <?php echo ucwords(str_replace('_', ' ', $payment['payment_method'])); ?></p>
                            <?php if(!empty($payment['reference_no'])): ?>
                            <p><strong>Reference No:</strong> <?php echo $payment['reference_no']; ?></p>
                            <?php endif; ?>
                        </div>
                        <div style="text-align: right;">
                            <h4 style="margin: 0 0 10px 0; color: #333;">Student Info</h4>
                            <p><strong><?php echo htmlspecialchars($payment['student_name']); ?></strong></p>
                            <p><?php echo $payment['email']; ?></p>
                            <p><?php echo $payment['phone']; ?></p>
                        </div>
                    </div>
                    
                    <!-- Course/Batch Info -->
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 6px; margin-bottom: 30px;">
                        <table style="width: 100%;">
                            <tr>
                                <td><strong>Course:</strong> <?php echo htmlspecialchars($payment['course_name']); ?></td>
                                <td><strong>Batch:</strong> <?php echo htmlspecialchars($payment['batch_name']); ?> (<?php echo $payment['batch_code']; ?>)</td>
                            </tr>
                            <tr>
                                <td><strong>Batch Period:</strong> <?php echo date('d M Y', strtotime($payment['start_date'])); ?> - <?php echo date('d M Y', strtotime($payment['end_date'])); ?></td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- Payment Details Table -->
                    <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
                        <thead>
                            <tr style="background: #007bff; color: white;">
                                <th style="padding: 12px; text-align: left;">Description</th>
                                <th style="padding: 12px; text-align: right;">Amount (₹)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr style="border-bottom: 1px solid #dee2e6;">
                                <td style="padding: 12px;">Course Fee</td>
                                <td style="padding: 12px; text-align: right;"><?php echo number_format($payment['total_fee'], 2); ?></td>
                            </tr>
                            <tr style="border-bottom: 1px solid #dee2e6;">
                                <td style="padding: 12px;">Previous Payments</td>
                                <td style="padding: 12px; text-align: right;"><?php echo number_format($payment['total_paid'] - $payment['amount'], 2); ?></td>
                            </tr>
                            <tr style="border-bottom: 2px solid #333; font-weight: bold;">
                                <td style="padding: 12px;">Current Payment</td>
                                <td style="padding: 12px; text-align: right;"><?php echo number_format($payment['amount'], 2); ?></td>
                            </tr>
                            <tr style="font-weight: bold; font-size: 16px;">
                                <td style="padding: 12px;">Total Paid</td>
                                <td style="padding: 12px; text-align: right;">₹<?php echo number_format($payment['total_paid'], 2); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    
                    <!-- Notes -->
                    <?php if(!empty($payment['notes'])): ?>
                    <div style="margin-bottom: 30px;">
                        <strong>Notes:</strong>
                        <p style="margin: 5px 0 0 0; color: #666;"><?php echo nl2br(htmlspecialchars($payment['notes'])); ?></p>
                    </div>
                    <?php endif; ?>
                    
                    <div style="margin-top: 30px; text-align: center; color: #666; font-size: 12px; border-top: 1px solid #dee2e6; padding-top: 20px;">
                        <p>This is a computer generated receipt and does not require physical signature.</p>
                        <p>Generated on: <?php echo date('d M Y h:i A'); ?></p>
                    </div>
                </div>
            </div>
            
            <style>
            /* Print styles - only show receipt content */
            @media print {
                body * {
                    visibility: hidden;
                }
                #receipt-content, #receipt-content * {
                    visibility: visible;
                }
                #receipt-content {
                    position: absolute;
                    left: 0;
                    top: 0;
                    width: 100%;
                    padding: 20px;
                    background: white;
                }
                .btn-primary, .btn-secondary, .card-header {
                    display: none !important;
                }
            }
            </style>
            
            <script>
            function printReceipt() {
                window.print();
            }
            </script>
            
            <?php
            require_once 'footer.php';
            exit();
        }
    }

    // Remove Student from Batch
    if (isset($_GET['remove_student'])) {
        $batch_id = intval($_GET['batch_id']);
        $student_id = intval($_GET['student_id']);
        
        // Get course_id for redirect
        $batch_info = $conn->query("SELECT course_id FROM batches WHERE id = $batch_id")->fetch_assoc();
        $redirect_course = $batch_info ? $batch_info['course_id'] : 0;
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Remove from fee_payments first
            if (!$conn->query("DELETE FROM fee_payments WHERE batch_id = $batch_id AND student_id = $student_id")) {
                throw new Exception("Error removing payment records: " . $conn->error);
            }
            
            // Remove from batch_fees
            if (!$conn->query("DELETE FROM batch_fees WHERE batch_id = $batch_id AND student_id = $student_id")) {
                throw new Exception("Error removing fee record: " . $conn->error);
            }
            
            // Then remove from batch_students
            if (!$conn->query("DELETE FROM batch_students WHERE batch_id = $batch_id AND student_id = $student_id")) {
                throw new Exception("Error removing student from batch: " . $conn->error);
            }
            
            $conn->commit();
            $message = '<div class="alert-success"><i class="fas fa-check-circle"></i> Student removed from batch successfully!</div>';
            echo '<script>setTimeout(function(){ window.location.href = "batches.php?course_id=' . $redirect_course . '"; }, 1500);</script>';
            
        } catch (Exception $e) {
            $conn->rollback();
            $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> ' . $e->getMessage() . '</div>';
        }
    }

    // GENERATE CERTIFICATE FROM BATCH
    if (isset($_GET['generate_certificate'])) {
        $batch_id = intval($_GET['batch_id']);
        $student_id = intval($_GET['student_id']);
        
        // Get course_id for redirect
        $batch_info = $conn->query("SELECT course_id FROM batches WHERE id = $batch_id")->fetch_assoc();
        $redirect_course = $batch_info ? $batch_info['course_id'] : 0;
        
        // Check if fee is fully paid - this only checks, doesn't block certificate generation
        $fee_check = $conn->query("SELECT total_fee, paid_amount, remaining_fee FROM batch_fees 
                                WHERE batch_id = $batch_id AND student_id = $student_id")->fetch_assoc();
        
        // Always allow certificate generation regardless of fee status
        // Get batch and course info
        $batch_info = $conn->query("SELECT b.*, c.id as course_id, c.name as course_name 
                                    FROM batches b 
                                    JOIN courses c ON b.course_id = c.id 
                                    WHERE b.id = $batch_id")->fetch_assoc();
        
        if ($batch_info) {
            $course_id = $batch_info['course_id'];
            $issue_date = date('Y-m-d');
            $certificate_code = 'CERT-' . strtoupper(uniqid());
            
            // Check if certificate already exists
            $check = $conn->query("SELECT id FROM certificates WHERE student_id = $student_id AND course_id = $course_id");
            
            if ($check->num_rows > 0) {
                $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Certificate already exists for this student!</div>';
            } else {
                $sql = "INSERT INTO certificates (certificate_code, student_id, course_id, batch_id, issue_date) 
                        VALUES ('$certificate_code', $student_id, $course_id, $batch_id, '$issue_date')";
                
                if ($conn->query($sql)) {
                    $message = '<div class="alert-success"><i class="fas fa-check-circle"></i> Certificate generated successfully! Code: ' . $certificate_code . '</div>';
                    echo '<script>setTimeout(function(){ window.location.href = "batches.php?course_id=' . $redirect_course . '"; }, 1500);</script>';
                } else {
                    $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Error: ' . $conn->error . '</div>';
                }
            }
        } else {
            $message = '<div class="alert-error"><i class="fas fa-exclamation-circle"></i> Batch information not found!</div>';
        }
    }

    // Get active courses for dropdown and course selection
    $courses = $conn->query("SELECT * FROM courses WHERE status = 'active' ORDER BY name");
    
    // Get selected course info if any
    $selected_course_info = null;
    if ($selected_course > 0) {
        $selected_course_info = $conn->query("SELECT * FROM courses WHERE id = $selected_course")->fetch_assoc();
    }

    // Get batches - either all or filtered by course
    $batches_query = "SELECT b.*, c.name as course_name, 
                     (SELECT COUNT(*) FROM batch_students WHERE batch_id = b.id) as student_count
                     FROM batches b 
                     JOIN courses c ON b.course_id = c.id";
    
    if ($selected_course > 0) {
        $batches_query .= " WHERE b.course_id = $selected_course";
    }
    
    $batches_query .= " ORDER BY b.created_at DESC";
    $batches = $conn->query($batches_query);
    ?>

    <div class="card">
        <div class="card-header">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                <h3 style="margin: 0;">
                    <i class="fas fa-layer-group"></i> 
                    <?php if($selected_course_info): ?>
                        Batches: <?php echo htmlspecialchars($selected_course_info['name']); ?>
                        <small style="font-size: 14px; color: #666; margin-left: 10px;">
                            Fee: ₹<?php echo number_format($selected_course_info['course_fee'] ?? 0, 2); ?>
                        </small>
                    <?php else: ?>
                        All Batches
                    <?php endif; ?>
                </h3>
                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <!-- Course Filter Dropdown -->
                    <select onchange="filterByCourse(this.value)" class="form-control" style="width: auto; min-width: 200px;">
                        <option value="0">All Courses</option>
                        <?php 
                        if($courses && $courses->num_rows > 0):
                            while($course = $courses->fetch_assoc()): 
                        ?>
                            <option value="<?php echo $course['id']; ?>" <?php echo $selected_course == $course['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($course['name']); ?> (₹<?php echo number_format($course['course_fee'] ?? 0, 2); ?>)
                            </option>
                        <?php 
                            endwhile;
                        endif; 
                        ?>
                    </select>
                    
                    <button class="btn-primary" onclick="openAddBatchModal()">
                        <i class="fas fa-plus-circle"></i> Create Batch
                    </button>
                </div>
            </div>
        </div>
        
        <div style="padding: 20px;">
            <?php echo $message; ?>
            
            <!-- Batches Table -->
            <?php if($batches && $batches->num_rows > 0): ?>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Batch Code</th>
                            <th>Batch Name</th>
                            <th>Course</th>
                            <th>Course Fee</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Students</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $batches->fetch_assoc()): 
                            $student_limit = $row['student_limit'] ?? 0;
                            $is_full = ($student_limit > 0 && $row['student_count'] >= $student_limit);
                            $course_fee = $row['course_fee'] ?? 0;
                            $status = $row['status'] ?? 'active';
                        ?>
                        <tr id="batch-row-<?php echo $row['id']; ?>">
                            <td><?php echo $row['id']; ?></td>
                            <td>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div style="width: 40px; height: 40px; background: #FF9800; 
                                        border-radius: 8px; display: flex; align-items: center; justify-content: center; color: white;">
                                        <i class="fas fa-layer-group"></i>
                                    </div>
                                    <div>
                                        <span style="font-weight: 500;"><?php echo $row['batch_code']; ?></span>
                                        <?php if($student_limit > 0): ?>
                                        <div style="font-size: 12px; color: #7f8c8d;">
                                            Limit: <?php echo $student_limit; ?> students
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo htmlspecialchars($row['batch_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['course_name']); ?></td>
                            <td style="font-weight: 600; color: #2c3e50;">
                                ₹<?php echo number_format($course_fee, 2); ?>
                            </td>
                            <td><?php echo date('d M Y', strtotime($row['start_date'])); ?></td>
                            <td><?php echo date('d M Y', strtotime($row['end_date'])); ?></td>
                            <td>
                                <span class="badge <?php echo $is_full ? 'badge-danger' : ($row['student_count'] > 0 ? 'badge-success' : 'badge-secondary'); ?>">
                                    <?php echo $row['student_count']; ?> / <?php echo $student_limit > 0 ? $student_limit : '∞'; ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge <?php echo $status == 'active' ? 'badge-success' : 'badge-secondary'; ?>">
                                    <?php echo ucfirst($status); ?>
                                </span>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <?php if($status == 'active'): ?>
                                    <button onclick="openStudentModal(<?php echo $row['id']; ?>, '<?php echo addslashes($row['batch_name']); ?>', <?php echo $student_limit; ?>, <?php echo $row['student_count']; ?>, <?php echo $course_fee; ?>)" 
                                            class="btn-sm btn-primary" <?php echo $is_full ? 'disabled style="opacity:0.5;"' : ''; ?>>
                                        <i class="fas fa-user-plus"></i> Add Student
                                    </button>
                                    <?php endif; ?>
                                    
                                    <button onclick="toggleStudents(<?php echo $row['id']; ?>)" 
                                            class="btn-sm btn-info toggle-students-btn" 
                                            id="toggle-btn-<?php echo $row['id']; ?>">
                                        <i class="fas fa-users"></i> View Students
                                    </button>
                                    
                                    <!-- Edit Batch Button -->
                                    <button onclick="openEditBatchModal(<?php echo $row['id']; ?>, '<?php echo addslashes($row['batch_name']); ?>', '<?php echo addslashes($row['batch_code']); ?>', <?php echo $student_limit; ?>, '<?php echo $row['start_date']; ?>', '<?php echo $row['end_date']; ?>', <?php echo $selected_course; ?>)" 
                                            class="btn-sm btn-edit">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    
                                    <?php if($status == 'active'): ?>
                                    <a href="?complete_batch=<?php echo $row['id']; ?>&course_id=<?php echo $selected_course; ?>" 
                                       class="btn-sm btn-success" 
                                       onclick="return confirm('Are you sure you want to mark this batch as completed? This action cannot be undone.')">
                                        <i class="fas fa-check-circle"></i> Complete
                                    </a>
                                    <?php endif; ?>
                                    
                                    <a href="?delete_batch=<?php echo $row['id']; ?>&course_id=<?php echo $selected_course; ?>" 
                                    class="btn-sm btn-danger" 
                                    onclick="return confirm('Are you sure you want to delete batch <?php echo addslashes($row['batch_name']); ?>? All student records and fees will be deleted!')">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                        
                        <!-- STUDENTS TABLE FOR THIS BATCH - HIDDEN BY DEFAULT -->
                        <tr id="students-row-<?php echo $row['id']; ?>" style="display: none;">
                            <td colspan="10" style="padding: 0; border-bottom: 2px solid #dee2e6;">
                                <div style="background: #f8f9fa; padding: 15px; margin-top: 5px; border-radius: 0 0 8px 8px;">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                        <h4 style="margin: 0; font-size: 16px; color: #2c3e50;">
                                            <i class="fas fa-users"></i> Students in Batch: <?php echo htmlspecialchars($row['batch_name']); ?>
                                        </h4>
                                        <div>
                                            <span style="font-size: 14px; color: #6c757d; margin-right: 10px;">
                                                Total: <?php echo $row['student_count']; ?> 
                                                <?php if($student_limit > 0): ?>
                                                | Limit: <?php echo $student_limit; ?> 
                                                | Available: <?php echo max(0, $student_limit - $row['student_count']); ?>
                                                <?php endif; ?>
                                            </span>
                                            <button onclick="toggleStudents(<?php echo $row['id']; ?>)" 
                                                    class="btn-sm btn-secondary">
                                                <i class="fas fa-times"></i> Close
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <?php 
                                    // Get students in this batch with their fee status and payment history
                                    $batch_students = $conn->query("SELECT s.*, 
                                                                    bf.total_fee, bf.paid_amount, bf.remaining_fee,
                                                                    bf.last_payment_date,
                                                                    (SELECT COUNT(*) FROM fee_payments WHERE batch_id = {$row['id']} AND student_id = s.id) as payment_count
                                                                    FROM students s 
                                                                    JOIN batch_students bs ON s.id = bs.student_id 
                                                                    LEFT JOIN batch_fees bf ON bs.batch_id = bf.batch_id AND bs.student_id = bf.student_id
                                                                    WHERE bs.batch_id = {$row['id']} 
                                                                    ORDER BY s.name");
                                    ?>
                                    
                                    <?php if($batch_students && $batch_students->num_rows > 0): ?>
                                    <div style="overflow-x: auto;">
                                        <table style="width: 100%; background: white; border-radius: 6px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                                            <thead>
                                                <tr>
                                                    <th style="padding: 10px; background: #e9ecef;">ID</th>
                                                    <th style="padding: 10px; background: #e9ecef;">Photo</th>
                                                    <th style="padding: 10px; background: #e9ecef;">Name</th>
                                                    <th style="padding: 10px; background: #e9ecef;">Email</th>
                                                    <th style="padding: 10px; background: #e9ecef;">Fee Status</th>
                                                    <th style="padding: 10px; background: #e9ecef;">Payments</th>
                                                    <th style="padding: 10px; background: #e9ecef;">Certificate</th>
                                                    <th style="padding: 10px; background: #e9ecef;">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while($student = $batch_students->fetch_assoc()): 
                                                    // Check if certificate already exists for this student in this course
                                                    $cert_check = $conn->query("SELECT c.id, c.certificate_code 
                                                                                FROM certificates c 
                                                                                WHERE c.student_id = {$student['id']} 
                                                                                AND c.course_id = {$row['course_id']}");
                                                    $has_certificate = $cert_check->num_rows > 0;
                                                    $cert_info = $has_certificate ? $cert_check->fetch_assoc() : null;
                                                    
                                                    // Fee status
                                                    $total_fee = $student['total_fee'] ?? $course_fee;
                                                    $paid_amount = $student['paid_amount'] ?? 0;
                                                    $remaining_fee = $student['remaining_fee'] ?? $total_fee;
                                                    $payment_percentage = $total_fee > 0 ? ($paid_amount / $total_fee) * 100 : 0;
                                                    $is_fee_paid = $remaining_fee <= 0;
                                                    
                                                    // Get recent payments for this student
                                                    $recent_payments = $conn->query("SELECT id, amount, payment_date, receipt_no 
                                                                                    FROM fee_payments 
                                                                                    WHERE batch_id = {$row['id']} AND student_id = {$student['id']}
                                                                                    ORDER BY payment_date DESC LIMIT 3");
                                                ?>
                                                <tr>
                                                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6;"><?php echo $student['id']; ?></td>
                                                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6;">
                                                        <?php if(!empty($student['photo'])): ?>
                                                            <img src="uploads/students/<?php echo $student['photo']; ?>" 
                                                                alt="<?php echo htmlspecialchars($student['name']); ?>"
                                                                style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;">
                                                        <?php else: ?>
                                                            <div style="width: 40px; height: 40px; border-radius: 50%; background: #e9ecef; 
                                                                display: flex; align-items: center; justify-content: center; color: #6c757d;">
                                                                <i class="fas fa-user"></i>
                                                            </div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6;">
                                                        <div style="font-weight: 500;"><?php echo htmlspecialchars($student['name']); ?></div>
                                                        <div style="font-size: 12px; color: #6c757d;">ID: <?php echo $student['id']; ?></div>
                                                    </td>
                                                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6;"><?php echo htmlspecialchars($student['email']); ?></td>
                                                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6;">
                                                        <div style="margin-bottom: 5px;">
                                                            <span style="font-size: 12px; color: #6c757d;">Total: ₹<?php echo number_format($total_fee, 2); ?></span>
                                                        </div>
                                                        <div style="margin-bottom: 5px;">
                                                            <span style="font-weight: 500; color: <?php echo $is_fee_paid ? '#28a745' : '#dc3545'; ?>;">
                                                                Paid: ₹<?php echo number_format($paid_amount, 2); ?>
                                                            </span>
                                                            <span style="color: #6c757d; margin-left: 10px;">
                                                                Remaining: ₹<?php echo number_format($remaining_fee, 2); ?>
                                                            </span>
                                                        </div>
                                                        <div style="background: #e9ecef; height: 6px; border-radius: 3px; overflow: hidden; margin-bottom: 5px;">
                                                            <div style="background: <?php echo $is_fee_paid ? '#28a745' : '#007bff'; ?>; 
                                                                height: 100%; width: <?php echo min(100, $payment_percentage); ?>%;">
                                                            </div>
                                                        </div>
                                                        <?php if($status == 'active'): ?>
                                                        <div style="display: flex; gap: 5px; flex-wrap: wrap;">
                                                            <button onclick="openPaymentModal(<?php echo $row['id']; ?>, <?php echo $student['id']; ?>, '<?php echo addslashes($student['name']); ?>', <?php echo $remaining_fee; ?>)" 
                                                                    class="btn-sm btn-success" style="padding: 3px 8px; font-size: 11px;"
                                                                    <?php echo $is_fee_paid ? 'disabled' : ''; ?>>
                                                                <i class="fas fa-money-bill-wave"></i> Add Payment
                                                            </button>
                                                        </div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6;">
                                                        <?php if($student['payment_count'] > 0): ?>
                                                            <div style="margin-bottom: 5px;">
                                                                <span class="badge badge-info" style="font-size: 11px;">
                                                                    <?php echo $student['payment_count']; ?> Payment<?php echo $student['payment_count'] > 1 ? 's' : ''; ?>
                                                                </span>
                                                            </div>
                                                            <?php if($recent_payments && $recent_payments->num_rows > 0): ?>
                                                                <div style="font-size: 11px;">
                                                                    <?php while($payment = $recent_payments->fetch_assoc()): ?>
                                                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 3px; padding: 2px 5px; background: #f8f9fa; border-radius: 3px;">
                                                                            <span>₹<?php echo number_format($payment['amount'], 2); ?></span>
                                                                            <span style="color: #666;"><?php echo date('d/m', strtotime($payment['payment_date'])); ?></span>
                                                                            <a href="?view_receipt=<?php echo $payment['id']; ?>&course_id=<?php echo $selected_course; ?>" 
                                                                               class="btn-sm btn-info" style="padding: 2px 5px; font-size: 10px;" target="_blank">
                                                                                <i class="fas fa-receipt"></i> Receipt
                                                                            </a>
                                                                        </div>
                                                                    <?php endwhile; ?>
                                                                </div>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <span style="color: #6c757d; font-size: 11px;">No payments yet</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6;">
                                                        <?php if($has_certificate): ?>
                                                            <span class="badge badge-success" style="font-size: 11px;">
                                                                <i class="fas fa-certificate"></i> Generated
                                                            </span>
                                                            <div style="font-size: 10px; color: #6c757d; margin-top: 2px;">
                                                                <?php echo $cert_info['certificate_code']; ?>
                                                            </div>
                                                        <?php else: ?>
                                                            <span class="badge <?php echo $is_fee_paid ? 'badge-warning' : 'badge-secondary'; ?>" style="font-size: 11px;">
                                                                <i class="fas fa-clock"></i> <?php echo $is_fee_paid ? 'Ready to Generate' : 'Fee Pending'; ?>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td style="padding: 10px; border-bottom: 1px solid #dee2e6;">
                                                        <div style="display: flex; gap: 5px; flex-wrap: wrap;">
                                                            <?php if($has_certificate): ?>
                                                                <a href="certificates.php?id=<?php echo $cert_info['id']; ?>" 
                                                                class="btn-sm btn-success" target="_blank" style="padding: 4px 8px; font-size: 12px;">
                                                                    <i class="fas fa-eye"></i> View Cert
                                                                </a>
                                                            <?php endif; ?>
                                                            
                                                            <!-- Always show Generate button if no certificate exists, regardless of fee status -->
                                                            <?php if(!$has_certificate): ?>
                                                                <a href="?generate_certificate&batch_id=<?php echo $row['id']; ?>&student_id=<?php echo $student['id']; ?>&course_id=<?php echo $selected_course; ?>" 
                                                                class="btn-sm btn-warning" style="padding: 4px 8px; font-size: 12px;"
                                                                onclick="return confirm('Generate certificate for <?php echo addslashes($student['name']); ?>?')">
                                                                    <i class="fas fa-certificate"></i> Generate
                                                                </a>
                                                            <?php endif; ?>
                                                            
                                                            <?php if($status == 'active'): ?>
                                                            <a href="?remove_student&batch_id=<?php echo $row['id']; ?>&student_id=<?php echo $student['id']; ?>&course_id=<?php echo $selected_course; ?>" 
                                                            class="btn-sm btn-danger" style="padding: 4px 8px; font-size: 12px;"
                                                            onclick="return confirm('Remove <?php echo addslashes($student['name']); ?> from batch <?php echo addslashes($row['batch_name']); ?>? This will also delete all fee records!')">
                                                                <i class="fas fa-times"></i> Remove
                                                            </a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                    <!-- Total Fee Summary -->
                                    <?php 
                                    $batch_fee_summary = $conn->query("SELECT 
                                                                    SUM(total_fee) as total_fees,
                                                                    SUM(paid_amount) as total_paid,
                                                                    SUM(remaining_fee) as total_remaining
                                                                    FROM batch_fees WHERE batch_id = {$row['id']}")->fetch_assoc();
                                    ?>
                                    <div style="margin-top: 15px; padding: 15px; background: white; border-radius: 6px; border: 1px solid #dee2e6;">
                                        <h5 style="margin: 0 0 10px 0; color: #2c3e50;">Batch Fee Summary</h5>
                                        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                                            <div>
                                                <div style="font-size: 12px; color: #6c757d;">Total Course Fees</div>
                                                <div style="font-size: 18px; font-weight: 600; color: #2c3e50;">
                                                    ₹<?php echo number_format($batch_fee_summary['total_fees'] ?? 0, 2); ?>
                                                </div>
                                            </div>
                                            <div>
                                                <div style="font-size: 12px; color: #6c757d;">Total Collected</div>
                                                <div style="font-size: 18px; font-weight: 600; color: #28a745;">
                                                    ₹<?php echo number_format($batch_fee_summary['total_paid'] ?? 0, 2); ?>
                                                </div>
                                            </div>
                                            <div>
                                                <div style="font-size: 12px; color: #6c757d;">Total Pending</div>
                                                <div style="font-size: 18px; font-weight: 600; color: #dc3545;">
                                                    ₹<?php echo number_format($batch_fee_summary['total_remaining'] ?? 0, 2); ?>
                                                </div>
                                            </div>
                                            <div>
                                                <div style="font-size: 12px; color: #6c757d;">Collection Rate</div>
                                                <div style="font-size: 18px; font-weight: 600; color: #007bff;">
                                                    <?php 
                                                    $total_fees = $batch_fee_summary['total_fees'] ?? 0;
                                                    $total_paid = $batch_fee_summary['total_paid'] ?? 0;
                                                    $collection_rate = $total_fees > 0 ? ($total_paid / $total_fees) * 100 : 0;
                                                    echo number_format($collection_rate, 1); ?>%
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                    <div style="text-align: center; padding: 20px; color: #6c757d; background: white; border-radius: 6px;">
                                        <i class="fas fa-user-friends" style="font-size: 32px; margin-bottom: 10px; opacity: 0.3;"></i>
                                        <p style="margin: 0;">No students in this batch yet. Add students using the "Add Student" button above.</p>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div style="text-align: center; padding: 40px; color: #7f8c8d;">
                <i class="fas fa-layer-group" style="font-size: 48px; margin-bottom: 20px; opacity: 0.5;"></i>
                <h3>No Batches Found</h3>
                <p>
                    <?php if($selected_course > 0 && $selected_course_info): ?>
                        No batches created for <?php echo htmlspecialchars($selected_course_info['name']); ?> yet.
                    <?php else: ?>
                        Create your first batch to get started.
                    <?php endif; ?>
                </p>
                <button class="btn-primary" onclick="openAddBatchModal()">
                    <i class="fas fa-plus-circle"></i> Create Batch
                </button>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Create Batch Modal -->
    <div id="addBatchModal" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-plus-circle"></i> Create New Batch</h3>
                <button type="button" class="close-modal" onclick="closeModal('addBatchModal')">&times;</button>
            </div>
            <form method="POST" id="batchForm">
                <div class="form-group">
                    <label for="courseSelect">Select Course *</label>
                    <select name="course_id" id="courseSelect" class="form-control" required>
                        <option value="">Select Course</option>
                        <?php 
                        // Reset courses pointer
                        $courses = $conn->query("SELECT * FROM courses WHERE status = 'active' ORDER BY name");
                        if ($courses && $courses->num_rows > 0):
                            while($course = $courses->fetch_assoc()): 
                        ?>
                            <option value="<?php echo $course['id']; ?>" <?php echo $selected_course == $course['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($course['name']); ?> (₹<?php echo number_format($course['course_fee'] ?? 0, 2); ?>)
                            </option>
                        <?php 
                            endwhile;
                        else: 
                        ?>
                            <option value="">No active courses available. Create a course first.</option>
                        <?php endif; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="batchName">Batch Name *</label>
                    <input type="text" name="batch_name" id="batchName" class="form-control" 
                        placeholder="Enter batch name (e.g., Morning Batch)" required>
                </div>
                
                <div class="form-group">
                    <label for="batchCode">Batch Code *</label>
                    <input type="text" name="batch_code" id="batchCode" class="form-control" 
                        placeholder="e.g., BATCH-2024-001" required>
                    <small style="color: #7f8c8d;">Unique identifier for the batch</small>
                </div>
                
                <div class="form-group">
                    <label for="startDate">Start Date *</label>
                    <input type="date" name="start_date" id="startDate" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="endDate">End Date *</label>
                    <input type="date" name="end_date" id="endDate" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="studentLimit">Student Limit *</label>
                    <input type="number" name="student_limit" id="studentLimit" class="form-control" 
                        placeholder="Enter student limit" min="1" required>
                    <small style="color: #7f8c8d;">Maximum number of students allowed in this batch</small>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn-secondary" onclick="closeModal('addBatchModal')">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" name="add_batch" class="btn-primary">
                        <i class="fas fa-save"></i> Create Batch
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Batch Modal -->
    <div id="editBatchModal" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-edit"></i> Edit Batch</h3>
                <button type="button" class="close-modal" onclick="closeModal('editBatchModal')">&times;</button>
            </div>
            <form method="POST" id="editBatchForm">
                <input type="hidden" name="batch_id" id="edit_batch_id">
                
                <div class="form-group">
                    <label for="edit_batch_name">Batch Name *</label>
                    <input type="text" name="batch_name" id="edit_batch_name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_batch_code">Batch Code *</label>
                    <input type="text" name="batch_code" id="edit_batch_code" class="form-control" required>
                    <small style="color: #7f8c8d;">Unique identifier for the batch</small>
                </div>
                
                <div class="form-group">
                    <label for="edit_start_date">Start Date *</label>
                    <input type="date" name="start_date" id="edit_start_date" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_end_date">End Date *</label>
                    <input type="date" name="end_date" id="edit_end_date" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_student_limit">Student Limit *</label>
                    <input type="number" name="student_limit" id="edit_student_limit" class="form-control" 
                        min="1" required>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn-secondary" onclick="closeModal('editBatchModal')">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" name="update_batch" class="btn-primary">
                        <i class="fas fa-save"></i> Update Batch
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Student Modal -->
    <div id="studentModal" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user-plus"></i> Add Student to Batch</h3>
                <button type="button" class="close-modal" onclick="closeModal('studentModal')">&times;</button>
            </div>
            <form method="POST" id="addStudentForm">
                <input type="hidden" name="batch_id" id="modal_batch_id">
                
                <div class="form-group">
                    <label for="modal_batch_name">Batch</label>
                    <input type="text" id="modal_batch_name" class="form-control" readonly style="background: #f8f9fa;">
                </div>
                
                <div class="form-group">
                    <label>Course Fee: <span id="courseFeeInfo" style="color: #2c3e50; font-weight: 600;"></span></label>
                </div>
                
                <div class="form-group">
                    <label>Capacity: <span id="capacityInfo" style="color: #7f8c8d;"></span></label>
                </div>
                
                <div class="form-group">
                    <label for="searchStudentInput">Search Student *</label>
                    <div style="position: relative;">
                        <input type="text" id="searchStudentInput" class="form-control" 
                            placeholder="Start typing student name or email..." 
                            autocomplete="off">
                        <div id="searchResults" style="display: none; position: absolute; top: 100%; left: 0; right: 0; 
                            background: white; border: 1px solid #ddd; border-radius: 0 0 6px 6px; 
                            max-height: 300px; overflow-y: auto; z-index: 1000; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                        </div>
                    </div>
                    <small style="color: #7f8c8d;">Type at least 2 characters to search</small>
                </div>
                
                <div class="form-group" style="display: none;" id="selectedStudentGroup">
                    <label>Selected Student</label>
                    <div style="background: #f8f9fa; padding: 10px; border-radius: 6px; display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <span id="selectedStudentName" style="font-weight: 500;"></span>
                            <div id="selectedStudentEmail" style="font-size: 12px; color: #7f8c8d;"></div>
                        </div>
                        <button type="button" class="btn-sm btn-secondary" onclick="clearSelectedStudent()">
                            <i class="fas fa-times"></i> Clear
                        </button>
                    </div>
                </div>
                
                <input type="hidden" name="student_id" id="selectedStudentId">
                
                <!-- Fee Options Section -->
                <div id="feeOptionsSection" style="display: none; margin-top: 20px; padding-top: 20px; border-top: 1px solid #dee2e6;">
                    <h4 style="margin-bottom: 15px; color: #2c3e50;"><i class="fas fa-money-bill-wave"></i> Fee Options</h4>
                    
                    <div class="form-group">
                        <label>Fee Type *</label>
                        <div style="margin-top: 10px;">
                            <div style="margin-bottom: 10px;">
                                <input type="radio" name="fee_option" id="fee_full" value="full_course" checked 
                                    onchange="toggleFeeOptions()">
                                <label for="fee_full" style="margin-left: 5px; cursor: pointer;">
                                    Full Course Fee (₹<span id="fullCourseFeeAmount">0</span>)
                                </label>
                            </div>
                            
                            <div style="margin-bottom: 10px;">
                                <input type="radio" name="fee_option" id="fee_partial" value="partially_paid"
                                    onchange="toggleFeeOptions()">
                                <label for="fee_partial" style="margin-left: 5px; cursor: pointer;">
                                    Partially Paid
                                </label>
                            </div>
                            
                            <div style="margin-bottom: 10px;">
                                <input type="radio" name="fee_option" id="fee_custom" value="custom_fee"
                                    onchange="toggleFeeOptions()">
                                <label for="fee_custom" style="margin-left: 5px; cursor: pointer;">
                                    Custom Fee
                                </label>
                            </div>
                            
                            <div style="margin-bottom: 10px;">
                                <input type="radio" name="fee_option" id="fee_free" value="no_fee"
                                    onchange="toggleFeeOptions()">
                                <label for="fee_free" style="margin-left: 5px; cursor: pointer;">
                                    No Fee (Free/Sponsored)
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Partially Paid Options -->
                    <div id="partialFeeOptions" style="display: none; background: #f8f9fa; padding: 15px; border-radius: 6px; margin-bottom: 15px;">
                        <div class="form-group">
                            <label for="initial_payment">Initial Payment Amount (₹)</label>
                            <input type="number" name="initial_payment" id="initial_payment" class="form-control" 
                                step="0.01" min="0.01" placeholder="Enter initial payment amount">
                            <small style="color: #7f8c8d;">The student has already paid this amount</small>
                        </div>
                    </div>
                    
                    <!-- Custom Fee Options -->
                    <div id="customFeeOptions" style="display: none; background: #f8f9fa; padding: 15px; border-radius: 6px; margin-bottom: 15px;">
                        <div class="form-group">
                            <label for="custom_fee">Custom Fee Amount (₹)</label>
                            <input type="number" name="custom_fee" id="custom_fee" class="form-control" 
                                step="0.01" min="0" placeholder="Enter custom fee amount">
                            <small style="color: #7f8c8d;">Set a different fee amount for this student</small>
                        </div>
                    </div>
                    
                    <!-- Fee Summary -->
                    <div id="feeSummary" style="background: #e9ecef; padding: 15px; border-radius: 6px; margin-top: 15px;">
                        <h5 style="margin: 0 0 10px 0; color: #2c3e50;">Fee Summary</h5>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span>Total Fee:</span>
                            <span id="summaryTotalFee" style="font-weight: 600;">₹0</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span>Paid Amount:</span>
                            <span id="summaryPaidAmount" style="font-weight: 600; color: #28a745;">₹0</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Remaining:</span>
                            <span id="summaryRemainingFee" style="font-weight: 600; color: #dc3545;">₹0</span>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn-secondary" onclick="closeModal('studentModal')">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" name="add_student_to_batch" class="btn-primary" id="addStudentBtn" disabled>
                        <i class="fas fa-user-plus"></i> Add Student
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Payment Modal -->
    <div id="paymentModal" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-money-bill-wave"></i> Add Fee Payment</h3>
                <button type="button" class="close-modal" onclick="closeModal('paymentModal')">&times;</button>
            </div>
            <form method="POST" id="paymentForm">
                <input type="hidden" name="batch_id" id="payment_batch_id">
                <input type="hidden" name="student_id" id="payment_student_id">
                
                <div class="form-group">
                    <label for="payment_student_name">Student</label>
                    <input type="text" id="payment_student_name" class="form-control" readonly style="background: #f8f9fa;">
                </div>
                
                <div class="form-group">
                    <label for="remaining_fee_display">Remaining Fee</label>
                    <input type="text" id="remaining_fee_display" class="form-control" readonly style="background: #f8f9fa;">
                </div>
                
                <div class="form-group">
                    <label for="payment_amount">Payment Amount * (₹)</label>
                    <input type="number" name="payment_amount" id="payment_amount" class="form-control" 
                        step="0.01" min="0.01" required placeholder="Enter payment amount">
                </div>
                
                <div class="form-group">
                    <label for="payment_date">Payment Date *</label>
                    <input type="date" name="payment_date" id="payment_date" class="form-control" 
                        value="<?php echo date('Y-m-d'); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="payment_method">Payment Method *</label>
                    <select name="payment_method" id="payment_method" class="form-control" required>
                        <option value="">Select Method</option>
                        <option value="cash">Cash</option>
                        <option value="bank_transfer">Bank Transfer</option>
                        <option value="cheque">Cheque</option>
                        <option value="card">Card</option>
                        <option value="online">Online Payment</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="reference_no">Reference Number</label>
                    <input type="text" name="reference_no" id="reference_no" class="form-control" 
                        placeholder="Transaction ID / Cheque No">
                </div>
                
                <div class="form-group">
                    <label for="notes">Notes</label>
                    <textarea name="notes" id="notes" class="form-control" rows="1" 
                            placeholder="Any additional notes about this payment"></textarea>
                </div>
                
                <div class="form-group" style="background: #e8f4fd; padding: 10px; border-radius: 4px;">
                    <i class="fas fa-info-circle" style="color: #007bff;"></i>
                    <small style="color: #0056b3;">A unique receipt number will be generated automatically</small>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn-secondary" onclick="closeModal('paymentModal')">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" name="add_fee_payment" class="btn-primary">
                        <i class="fas fa-save"></i> Record Payment & Generate Receipt
                    </button>
                </div>
            </form>
        </div>
    </div>


    <script>
    // Global variables
    let currentCourseFee = 0;

    // Initialize when page loads
    document.addEventListener('DOMContentLoaded', function() {
        console.log('DOM loaded');
        
        // Set today's date in payment date field
        const today = new Date().toISOString().split('T')[0];
        if (document.getElementById('payment_date')) {
            document.getElementById('payment_date').value = today;
        }
        
        // Fee options change listeners
        const initialPaymentInput = document.getElementById('initial_payment');
        const customFeeInput = document.getElementById('custom_fee');
        
        if (initialPaymentInput) {
            initialPaymentInput.addEventListener('input', updateFeeSummary);
        }
        
        if (customFeeInput) {
            customFeeInput.addEventListener('input', updateFeeSummary);
        }
        
        // Set default dates for batch creation modal - NO DATE RESTRICTIONS
        const startDateInput = document.getElementById('startDate');
        const endDateInput = document.getElementById('endDate');
        
        if (startDateInput) {
            const today = new Date().toISOString().split('T')[0];
            startDateInput.value = today;
            // No min date restriction - can select any date including past dates
        }
        
        if (endDateInput && startDateInput) {
            // Set default end date to 3 months from now
            const endDate = new Date();
            endDate.setMonth(endDate.getMonth() + 3);
            endDateInput.value = endDate.toISOString().split('T')[0];
            // No min date restriction
            
            // Only validate that end date is not before start date
            startDateInput.addEventListener('change', function() {
                if (endDateInput.value && endDateInput.value < this.value) {
                    endDateInput.value = this.value;
                }
            });
        }
    });

    // Filter batches by course
    function filterByCourse(courseId) {
        window.location.href = 'batches.php?course_id=' + courseId;
    }

    // Global function to toggle students visibility
    function toggleStudents(batchId) {
        console.log('toggleStudents called for batch:', batchId);
        const studentsRow = document.getElementById('students-row-' + batchId);
        const toggleBtn = document.getElementById('toggle-btn-' + batchId);
        
        if (!studentsRow || !toggleBtn) {
            console.error('Elements not found');
            return;
        }
        
        if (studentsRow.style.display === 'none') {
            // Show students
            studentsRow.style.display = 'table-row';
            toggleBtn.innerHTML = '<i class="fas fa-eye-slash"></i> Hide Students';
            toggleBtn.classList.remove('btn-info');
            toggleBtn.classList.add('btn-warning');
        } else {
            // Hide students
            studentsRow.style.display = 'none';
            toggleBtn.innerHTML = '<i class="fas fa-users"></i> View Students';
            toggleBtn.classList.remove('btn-warning');
            toggleBtn.classList.add('btn-info');
        }
    }

    // Global function to open student modal
    function openStudentModal(batchId, batchName, studentLimit, currentCount, course_fee) {
        console.log('openStudentModal called');
        
        // Store course fee globally
        currentCourseFee = parseFloat(course_fee);
        
        document.getElementById('modal_batch_id').value = batchId;
        document.getElementById('modal_batch_name').value = batchName;
        document.getElementById('courseFeeInfo').textContent = '₹' + currentCourseFee.toFixed(2);
        document.getElementById('fullCourseFeeAmount').textContent = currentCourseFee.toFixed(2);
        
        // Update capacity info
        const capacityInfo = document.getElementById('capacityInfo');
        if (studentLimit > 0) {
            capacityInfo.innerHTML = `${currentCount}/${studentLimit} students`;
            if (currentCount >= studentLimit) {
                capacityInfo.style.color = '#f44336';
                capacityInfo.innerHTML += ' (FULL)';
            } else {
                capacityInfo.style.color = '#4CAF50';
            }
        } else {
            capacityInfo.innerHTML = `${currentCount} students (No limit)`;
            capacityInfo.style.color = '#7f8c8d';
        }
        
        // Reset search and fee options
        clearSelectedStudent();
        resetFeeOptions();
        
        document.getElementById('studentModal').style.display = 'block';
    }

    // Function to open edit batch modal - NO DATE RESTRICTIONS
    function openEditBatchModal(batchId, batchName, batchCode, studentLimit, startDate, endDate, courseId) {
        console.log('openEditBatchModal called');
        
        document.getElementById('edit_batch_id').value = batchId;
        document.getElementById('edit_batch_name').value = batchName;
        document.getElementById('edit_batch_code').value = batchCode;
        document.getElementById('edit_student_limit').value = studentLimit;
        document.getElementById('edit_start_date').value = startDate;
        document.getElementById('edit_end_date').value = endDate;
        
        // No min date restrictions - can select any date including past dates
        const editStartDate = document.getElementById('edit_start_date');
        const editEndDate = document.getElementById('edit_end_date');
        
        // Remove any existing event listeners to avoid duplicates
        editStartDate.replaceWith(editStartDate.cloneNode(true));
        const newEditStartDate = document.getElementById('edit_start_date');
        const newEditEndDate = document.getElementById('edit_end_date');
        
        // Only validate that end date is not before start date
        newEditStartDate.addEventListener('change', function() {
            if (newEditEndDate.value && newEditEndDate.value < this.value) {
                newEditEndDate.value = this.value;
            }
        });
        
        document.getElementById('editBatchModal').style.display = 'block';
    }

    // Global function to open payment modal
    function openPaymentModal(batchId, studentId, studentName, remainingFee) {
        console.log('openPaymentModal called');
        document.getElementById('payment_batch_id').value = batchId;
        document.getElementById('payment_student_id').value = studentId;
        document.getElementById('payment_student_name').value = studentName;
        document.getElementById('remaining_fee_display').value = '₹' + parseFloat(remainingFee).toFixed(2);
        
        // Reset form
        document.getElementById('payment_amount').value = '';
        document.getElementById('payment_method').value = '';
        document.getElementById('reference_no').value = '';
        document.getElementById('notes').value = '';
        
        // Set today's date
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('payment_date').value = today;
        
        // Set max payment amount
        const paymentAmountInput = document.getElementById('payment_amount');
        paymentAmountInput.max = parseFloat(remainingFee).toFixed(2);
        
        document.getElementById('paymentModal').style.display = 'block';
    }

    // Global function to close modal
    function closeModal(modalId) {
        console.log('closeModal called:', modalId);
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'none';
        }
    }

    // Global function to open add batch modal
    function openAddBatchModal() {
        console.log('openAddBatchModal called');
        document.getElementById('addBatchModal').style.display = 'block';
    }

    // Reset student modal
    function clearSelectedStudent() {
        const searchInput = document.getElementById('searchStudentInput');
        const searchResults = document.getElementById('searchResults');
        
        if (searchInput) searchInput.value = '';
        if (searchResults) {
            searchResults.style.display = 'none';
            searchResults.innerHTML = '';
        }
        
        const selectedStudentGroup = document.getElementById('selectedStudentGroup');
        if (selectedStudentGroup) {
            selectedStudentGroup.style.display = 'none';
            document.getElementById('selectedStudentId').value = '';
            document.getElementById('selectedStudentName').textContent = '';
            document.getElementById('selectedStudentEmail').textContent = '';
            document.getElementById('addStudentBtn').disabled = true;
            document.getElementById('feeOptionsSection').style.display = 'none';
        }
    }

    // Select student from search results
    function selectStudent(studentId, studentName, studentEmail) {
        console.log('selectStudent called:', studentId, studentName);
        document.getElementById('selectedStudentId').value = studentId;
        document.getElementById('selectedStudentName').textContent = studentName;
        document.getElementById('selectedStudentEmail').textContent = studentEmail;
        document.getElementById('selectedStudentGroup').style.display = 'block';
        
        // Show fee options
        document.getElementById('feeOptionsSection').style.display = 'block';
        
        const searchResults = document.getElementById('searchResults');
        if (searchResults) {
            searchResults.style.display = 'none';
            searchResults.innerHTML = '';
        }
        
        const searchInput = document.getElementById('searchStudentInput');
        if (searchInput) {
            searchInput.value = '';
        }
        
        document.getElementById('addStudentBtn').disabled = false;
        
        // Update fee summary
        updateFeeSummary();
    }

    // Toggle fee options based on selection
    function toggleFeeOptions() {
        const partialFeeOptions = document.getElementById('partialFeeOptions');
        const customFeeOptions = document.getElementById('customFeeOptions');
        
        // Get selected option
        const selectedOption = document.querySelector('input[name="fee_option"]:checked').value;
        
        // Hide all options first
        partialFeeOptions.style.display = 'none';
        customFeeOptions.style.display = 'none';
        
        // Show relevant options
        if (selectedOption === 'partially_paid') {
            partialFeeOptions.style.display = 'block';
        } else if (selectedOption === 'custom_fee') {
            customFeeOptions.style.display = 'block';
        }
        
        // Update fee summary
        updateFeeSummary();
    }

    // Update fee summary based on selections
    function updateFeeSummary() {
        const selectedOption = document.querySelector('input[name="fee_option"]:checked').value;
        
        let totalFee = currentCourseFee;
        let paidAmount = 0;
        
        if (selectedOption === 'no_fee') {
            totalFee = 0;
            paidAmount = 0;
        } else if (selectedOption === 'custom_fee') {
            const customFeeInput = document.getElementById('custom_fee');
            const customFee = parseFloat(customFeeInput.value) || 0;
            totalFee = customFee;
            paidAmount = 0;
        } else if (selectedOption === 'partially_paid') {
            const initialPaymentInput = document.getElementById('initial_payment');
            const initialPayment = parseFloat(initialPaymentInput.value) || 0;
            paidAmount = Math.min(initialPayment, totalFee);
        }
        
        const remainingFee = Math.max(0, totalFee - paidAmount);
        
        // Update summary display
        document.getElementById('summaryTotalFee').textContent = '₹' + totalFee.toFixed(2);
        document.getElementById('summaryPaidAmount').textContent = '₹' + paidAmount.toFixed(2);
        document.getElementById('summaryRemainingFee').textContent = '₹' + remainingFee.toFixed(2);
    }

    // Reset fee options to default
    function resetFeeOptions() {
        // Reset to full course fee option
        document.getElementById('fee_full').checked = true;
        
        // Clear input fields
        document.getElementById('initial_payment').value = '';
        document.getElementById('custom_fee').value = '';
        
        // Hide options
        document.getElementById('partialFeeOptions').style.display = 'none';
        document.getElementById('customFeeOptions').style.display = 'none';
        
        // Update summary
        updateFeeSummary();
    }

    // Search functionality for students
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('searchStudentInput');
        if (searchInput) {
            let searchTimeout;
            
            searchInput.addEventListener('input', function() {
                clearTimeout(searchTimeout);
                const searchTerm = this.value.trim();
                const resultsDiv = document.getElementById('searchResults');
                
                if (searchTerm.length < 2) {
                    resultsDiv.style.display = 'none';
                    return;
                }
                
                searchTimeout = setTimeout(() => {
                    // Get current batch ID from the modal
                    const batchId = document.getElementById('modal_batch_id').value || 0;
                    
                    fetch('search_students_ajax.php?search=' + encodeURIComponent(searchTerm) + '&batch_id=' + batchId)
                        .then(response => response.text())
                        .then(data => {
                            resultsDiv.innerHTML = data;
                            resultsDiv.style.display = 'block';
                            
                            // Add click event to search results
                            document.querySelectorAll('.search-result-item').forEach(item => {
                                const isAlreadyInBatch = item.getAttribute('data-in-batch') === 'true';
                                
                                if (!isAlreadyInBatch) {
                                    item.style.cursor = 'pointer';
                                    item.addEventListener('click', function() {
                                        const studentId = this.getAttribute('data-id');
                                        const studentName = this.querySelector('.student-name').textContent.trim();
                                        const studentEmail = this.querySelector('.student-email').textContent.trim();
                                        selectStudent(studentId, studentName, studentEmail);
                                    });
                                } else {
                                    item.style.cursor = 'not-allowed';
                                    item.title = 'Student is already in this batch';
                                    item.addEventListener('click', function(e) {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        alert('This student is already in this batch!');
                                    });
                                }
                            });
                        })
                        .catch(error => {
                            console.error('Search error:', error);
                            resultsDiv.innerHTML = '<div style="padding: 15px; color: #f44336;">Search error. Please try again.</div>';
                            resultsDiv.style.display = 'block';
                        });
                }, 300);
            });
            
            // Hide search results when clicking elsewhere
            document.addEventListener('click', function(e) {
                const searchResults = document.getElementById('searchResults');
                if (searchResults && !e.target.closest('#searchStudentInput') && !e.target.closest('#searchResults')) {
                    searchResults.style.display = 'none';
                }
            });
        }
        
        // Payment form validation
        const paymentForm = document.getElementById('paymentForm');
        if (paymentForm) {
            paymentForm.addEventListener('submit', function(e) {
                const paymentAmount = parseFloat(document.getElementById('payment_amount').value);
                const remainingFeeText = document.getElementById('remaining_fee_display').value;
                const remainingFee = parseFloat(remainingFeeText.replace(/[^0-9.-]+/g, ""));
                
                if (isNaN(paymentAmount) || paymentAmount <= 0) {
                    e.preventDefault();
                    alert('Please enter a valid payment amount greater than 0!');
                    return;
                }
                
                if (paymentAmount > remainingFee) {
                    e.preventDefault();
                    alert('Payment amount cannot be greater than remaining fee!\nRemaining Fee: ₹' + remainingFee.toFixed(2));
                }
            });
        }
    });
    </script>

    <style>
    .modal {
        display: none;
        position: fixed;
        z-index: 2000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.5);
        overflow-y: auto;
    }

    .modal-content {
        background-color: #fff;
        margin: 50px auto;
        padding: 20px;
        border-radius: 8px;
        width: 90%;
        max-width: 600px;
        position: relative;
    }

    .close-modal {
        position: absolute;
        right: 20px;
        top: 15px;
        font-size: 28px;
        font-weight: bold;
        color: #aaa;
        background: none;
        border: none;
        cursor: pointer;
        padding: 0;
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .close-modal:hover {
        color: #000;
    }

    .badge-danger {
        background: #f8d7da;
        color: #721c24;
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 12px;
    }

    .badge-success {
        background: #d4edda;
        color: #155724;
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 12px;
    }

    .badge-secondary {
        background: #e9ecef;
        color: #6c757d;
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 12px;
    }

    .badge-warning {
        background: #fff3cd;
        color: #856404;
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 12px;
    }

    .badge-info {
        background: #d1ecf1;
        color: #0c5460;
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 12px;
    }

    .search-result-item {
        padding: 10px 15px;
        cursor: pointer;
        border-bottom: 1px solid #eee;
        transition: background 0.2s;
    }

    .search-result-item:hover {
        background: #f8f9fa;
    }

    .search-result-item:last-child {
        border-bottom: none;
    }

    .student-name {
        font-weight: 500;
        display: block;
    }

    .student-email {
        font-size: 12px;
        color: #7f8c8d;
        display: block;
    }

    /* Action buttons */
    .action-buttons {
        display: flex;
        gap: 5px;
        flex-wrap: wrap;
    }

    .btn-sm {
        padding: 6px 10px;
        font-size: 12px;
        border-radius: 4px;
        border: none;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        text-decoration: none;
    }

    .btn-primary {
        background: #007bff;
        color: white;
        border: 1px solid #007bff;
    }

    .btn-primary:hover {
        background: #0069d9;
        border-color: #0069d9;
    }

    .btn-primary:disabled {
        background: #6c757d;
        border-color: #6c757d;
        cursor: not-allowed;
    }

    .btn-danger {
        background: #dc3545;
        color: white;
        border: 1px solid #dc3545;
    }

    .btn-danger:hover {
        background: #c82333;
        border-color: #bd2130;
    }

    .btn-info {
        background: #17a2b8;
        color: white;
        border: 1px solid #17a2b8;
    }

    .btn-info:hover {
        background: #138496;
        border-color: #117a8b;
    }

    .btn-warning {
        background: #ffc107;
        color: #212529;
        border: 1px solid #ffc107;
    }

    .btn-warning:hover {
        background: #e0a800;
        border-color: #d39e00;
    }

    .btn-success {
        background: #28a745;
        color: white;
        border: 1px solid #28a745;
    }

    .btn-success:hover {
        background: #218838;
        border-color: #1e7e34;
    }

    .btn-success:disabled {
        background: #6c757d;
        border-color: #6c757d;
        cursor: not-allowed;
    }

    .btn-secondary {
        background: #6c757d;
        color: white;
        border: 1px solid #6c757d;
    }

    .btn-secondary:hover {
        background: #5a6268;
        border-color: #545b62;
    }

    .btn-edit {
        background: #ffc107;
        color: #212529;
        border: 1px solid #ffc107;
    }

    .btn-edit:hover {
        background: #e0a800;
        border-color: #d39e00;
    }

    .form-group {
        margin-bottom: 15px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: 500;
        color: #333;
    }

    .form-control {
        width: 100%;
        padding: 8px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
        transition: border-color 0.2s;
    }

    .form-control:focus {
        outline: none;
        border-color: #007bff;
        box-shadow: 0 0 0 2px rgba(0,123,255,0.25);
    }

    input[type="radio"] {
        margin-right: 5px;
    }

    .alert-success {
        background: #d4edda;
        color: #155724;
        padding: 12px;
        border-radius: 4px;
        margin-bottom: 15px;
        border: 1px solid #c3e6cb;
    }

    .alert-error {
        background: #f8d7da;
        color: #721c24;
        padding: 12px;
        border-radius: 4px;
        margin-bottom: 15px;
        border: 1px solid #f5c6cb;
    }

    /* Print styles */
    @media print {
        body * {
            visibility: hidden;
        }
        #receipt-content, #receipt-content * {
            visibility: visible;
        }
        #receipt-content {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            padding: 20px;
            background: white;
        }
        .btn-primary, .btn-secondary, .card-header {
            display: none !important;
        }
    }
    </style>

    <?php 
    $conn->close();
    require_once 'footer.php'; 
    ?>