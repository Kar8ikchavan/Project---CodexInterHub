<?php
$conn = new mysqli('localhost', 'root', '', 'codexlabz_internship');
$course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;

if ($course_id > 0) {
    $sql = "SELECT start_date, end_date FROM courses WHERE id = $course_id";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        $course = $result->fetch_assoc();
        $start_date = date('d M Y', strtotime($course['start_date']));
        $end_date = date('d M Y', strtotime($course['end_date']));
        
        echo '<div style="color: #4CAF50;"><i class="fas fa-calendar-check"></i> Course Dates</div>';
        echo '<div style="margin-top: 5px;">';
        echo '<div><i class="fas fa-play-circle"></i> Start: ' . $start_date . '</div>';
        echo '<div><i class="fas fa-flag-checkered"></i> End: ' . $end_date . '</div>';
        echo '</div>';
        echo '<div style="margin-top: 10px; font-size: 12px; color: #FF9800;">';
        echo '<i class="fas fa-info-circle"></i> These dates will be used for the batch';
        echo '</div>';
    } else {
        echo '<div style="color: #f44336;"><i class="fas fa-exclamation-triangle"></i> Course not found</div>';
    }
} else {
    echo '<div style="color: #7f8c8d;"><i class="fas fa-info-circle"></i> Please select a course</div>';
}

$conn->close();
?>