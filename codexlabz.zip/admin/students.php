<?php
require_once 'header.php';

$conn = getConnection();
$message = '';

// Add/Update Student
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_student'])) {
        // Add new student
        $name = $conn->real_escape_string($_POST['name']);
        $email = $conn->real_escape_string($_POST['email']);
        $phone = $conn->real_escape_string($_POST['phone']);
        $gender = $conn->real_escape_string($_POST['gender']);
        $education = $conn->real_escape_string($_POST['education']);
        $city = $conn->real_escape_string($_POST['city']);
        
        // Check if email exists
        $check = $conn->query("SELECT id FROM students WHERE email = '$email'");
        
        if ($check->num_rows > 0) {
            $message = '<div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> Email already exists!</div>';
        } else {
            $sql = "INSERT INTO students (name, email, phone, gender, education, city) 
                    VALUES ('$name', '$email', '$phone', '$gender', '$education', '$city')";
            
            if ($conn->query($sql)) {
                $message = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Student added successfully!</div>';
                echo '<script>window.location.href="students.php";</script>';
                exit();
            } else {
                $message = '<div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> Error: ' . $conn->error . '</div>';
            }
        }
    } elseif (isset($_POST['update_student'])) {
        // Update student from modal
        $student_id = intval($_POST['student_id']);
        $name = $conn->real_escape_string($_POST['name']);
        $email = $conn->real_escape_string($_POST['email']);
        $phone = $conn->real_escape_string($_POST['phone']);
        $gender = $conn->real_escape_string($_POST['gender']);
        $education = $conn->real_escape_string($_POST['education']);
        $city = $conn->real_escape_string($_POST['city']);
        
        // Check if email exists for another student
        $check = $conn->query("SELECT id FROM students WHERE email = '$email' AND id != $student_id");
        
        if ($check->num_rows > 0) {
            $message = '<div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> Email already exists for another student!</div>';
        } else {
            $sql = "UPDATE students SET 
                    name = '$name',
                    email = '$email',
                    phone = '$phone',
                    gender = '$gender',
                    education = '$education',
                    city = '$city'
                    WHERE id = $student_id";
            
            if ($conn->query($sql)) {
                $message = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Student updated successfully!</div>';
                echo '<script>
                    alert("Student updated successfully!");
                    window.location.href="students.php";
                </script>';
                exit();
            } else {
                $message = '<div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> Error: ' . $conn->error . '</div>';
            }
        }
    }
}

// Delete Student
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM students WHERE id = $id");
    echo '<script>window.location.href="students.php";</script>';
    exit();
}

// Search functionality
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
if ($search) {
    $students = $conn->query("SELECT * FROM students WHERE 
                              name LIKE '%$search%' OR 
                              email LIKE '%$search%' OR 
                              phone LIKE '%$search%'
                              ORDER BY id DESC");
} else {
    $students = $conn->query("SELECT * FROM students ORDER BY id DESC");
}

$total_students = $students->num_rows;

// Add city column if not exists
$check_city = $conn->query("SHOW COLUMNS FROM students LIKE 'city'");
if ($check_city->num_rows == 0) {
    $conn->query("ALTER TABLE students ADD COLUMN city VARCHAR(255) DEFAULT NULL");
}
?>

<style>
/* Alerts */
.alert {
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
    animation: slideIn 0.3s ease;
}

.alert-success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.alert-error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

@keyframes slideIn {
    from { transform: translateY(-10px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

/* City Badge */
.city-badge {
    background: #e3f2fd;
    color: #1976d2;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
    display: inline-flex;
    align-items: center;
    gap: 3px;
}

.city-badge i {
    font-size: 10px;
}

/* View Button */
.btn-view {
    background: #17a2b8;
    color: white;
    border: 1px solid #17a2b8;
}

.btn-view:hover {
    background: #138496;
    border-color: #117a8b;
}

/* Student Detail Modal */
.student-detail-modal .modal-content {
    max-width: 800px;
    width: 95%;
}

.student-profile-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 30px;
    border-radius: 8px 8px 0 0;
    margin: -25px -25px 20px -25px;
    position: relative;
    text-align: center;
}

.student-avatar-large {
    width: 80px;
    height: 80px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 36px;
    font-weight: bold;
    color: #667eea;
    margin: 0 auto 15px auto;
    border: 3px solid rgba(255,255,255,0.3);
}

.edit-mode-btn {
    position: absolute;
    top: 20px;
    right: 20px;
    background: rgba(255,255,255,0.2);
    color: white;
    border: 1px solid rgba(255,255,255,0.5);
    padding: 8px 15px;
    border-radius: 20px;
    cursor: pointer;
    transition: all 0.3s;
}

.edit-mode-btn:hover {
    background: rgba(255,255,255,0.3);
}

.detail-section {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
}

.detail-section h4 {
    margin: 0 0 15px 0;
    color: #2c3e50;
    display: flex;
    align-items: center;
    gap: 10px;
    border-bottom: 2px solid #dee2e6;
    padding-bottom: 10px;
}

.detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
}

.detail-item {
    display: flex;
    flex-direction: column;
}

.detail-label {
    font-size: 12px;
    color: #7f8c8d;
    margin-bottom: 3px;
}

.detail-value {
    font-weight: 500;
    color: #2c3e50;
}

/* Edit Form Styles */
.edit-form-section {
    background: white;
    border-radius: 8px;
    padding: 20px;
    margin-top: 20px;
    border: 2px solid #667eea;
    display: none;
}

.edit-form-section.show {
    display: block;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.edit-form-section h4 {
    color: #667eea;
    margin-bottom: 20px;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: 500;
    color: #333;
}

.form-control {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
}

.form-control:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1);
}

/* Modal Actions */
.modal-actions {
    display: flex;
    gap: 10px;
    justify-content: flex-end;
    margin-top: 20px;
}

/* Student row clickable */
.student-row {
    cursor: pointer;
    transition: background 0.2s;
}

.student-row:hover {
    background: #f0f2f5 !important;
}

/* Badges */
.badge {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
}

.badge-info {
    background: #d1ecf1;
    color: #0c5460;
}

.badge-warning {
    background: #fff3cd;
    color: #856404;
}

/* Action Buttons */
.action-buttons {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
}

.btn-sm {
    padding: 6px 10px;
    font-size: 12px;
    border-radius: 4px;
    border: none;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    text-decoration: none;
}

.btn-primary {
    background: #007bff;
    color: white;
}

.btn-secondary {
    background: #6c757d;
    color: white;
}

.btn-danger {
    background: #dc3545;
    color: white;
}

.btn-success {
    background: #28a745;
    color: white;
}

/* Modal */
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.7);
    z-index: 1000;
    overflow-y: auto;
    padding: 20px;
}

.modal-content {
    background: white;
    border-radius: 12px;
    margin: 50px auto;
    max-width: 800px;
    animation: modalSlideIn 0.3s ease;
}

@keyframes modalSlideIn {
    from { transform: translateY(-50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

.modal-header {
    padding: 25px;
    border-bottom: 1px solid #e0e0e0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 {
    color: #2c3e50;
    font-size: 22px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.close-modal {
    background: none;
    border: none;
    font-size: 28px;
    color: #7f8c8d;
    cursor: pointer;
    transition: color 0.3s;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
}

.close-modal:hover {
    color: #e74c3c;
    background: #f9f9f9;
}

/* Table Styles */
.table-container {
    overflow-x: auto;
    border-radius: 8px;
    border: 1px solid #e0e0e0;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 1000px;
}

thead {
    background: #f8f9fa;
}

th {
    padding: 18px 15px;
    text-align: left;
    font-weight: 600;
    color: #495057;
    border-bottom: 2px solid #dee2e6;
}

td {
    padding: 16px 15px;
    border-bottom: 1px solid #e0e0e0;
    vertical-align: middle;
}

/* No Data State */
.no-data {
    text-align: center;
    padding: 60px 20px;
    color: #7f8c8d;
}

.no-data i {
    font-size: 64px;
    margin-bottom: 20px;
    opacity: 0.3;
}

.no-data h3 {
    margin-bottom: 10px;
    color: #95a5a6;
}

/* Card Styles */
.card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    overflow: hidden;
    margin-bottom: 30px;
}

.card-header {
    padding: 25px;
    background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
}

.card-header h3 {
    font-size: 24px;
    display: flex;
    align-items: center;
    color: white;
    gap: 10px;
}
</style>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-users"></i> Students Management</h3>
        <button class="btn-primary" onclick="openModal('addStudentModal')">
            <i class="fas fa-user-plus"></i> Add Student
        </button>
    </div>
    
    <div style="padding: 20px;">
        <?php echo $message; ?>
        
        <!-- Search Bar -->
        <div class="form-group" style="max-width: 400px; margin-bottom: 20px;">
            <form method="GET" action="">
                <div style="display: flex; gap: 10px;">
                    <input type="text" name="search" class="form-control" 
                           placeholder="Search students by name, email or phone..." 
                           value="<?php echo htmlspecialchars($search); ?>">
                    <button type="submit" class="btn-primary">
                        <i class="fas fa-search"></i> Search
                    </button>
                    <?php if($search): ?>
                        <a href="students.php" class="btn-secondary">
                            <i class="fas fa-times"></i> Clear
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        
        <!-- Stats -->
        <div style="display: flex; gap: 15px; margin-bottom: 20px; flex-wrap: wrap;">
            <div style="background: #f8f9fa; padding: 10px 20px; border-radius: 6px;">
                <small style="color: #7f8c8d;">Total Students</small>
                <h4 style="margin: 5px 0; color: #2c3e50;"><?php echo $total_students; ?></h4>
            </div>
        </div>
        
        <!-- Students Table -->
        <?php if($total_students > 0): ?>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Student</th>
                        <th>Contact</th>
                        <th>Gender</th>
                        <th>Education</th>
                        <th>City</th>
                        <th>Joined</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $students->fetch_assoc()): ?>
                    <tr class="student-row" onclick="viewStudentDetails(<?php echo $row['id']; ?>, <?php echo htmlspecialchars(json_encode($row)); ?>)">
                        <td><?php echo $row['id']; ?></td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div style="width: 35px; height: 35px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                                      border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white;">
                                    <?php echo strtoupper(substr($row['name'], 0, 1)); ?>
                                </div>
                                <div>
                                    <div style="font-weight: 500;"><?php echo htmlspecialchars($row['name']); ?></div>
                                    <div style="font-size: 11px; color: #6c757d;">
                                        <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($row['email']); ?>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <i class="fas fa-phone"></i> <?php echo htmlspecialchars($row['phone']); ?>
                        </td>
                        <td>
                            <span class="badge <?php echo $row['gender'] == 'Male' ? 'badge-info' : 'badge-warning'; ?>">
                                <?php echo $row['gender']; ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($row['education']); ?></td>
                        <td>
                            <?php if(!empty($row['city'])): ?>
                                <span class="city-badge">
                                    <i class="fas fa-map-marker-alt"></i> 
                                    <?php echo htmlspecialchars($row['city']); ?>
                                </span>
                            <?php else: ?>
                                <span style="color: #95a5a6;">N/A</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                        <td onclick="event.stopPropagation();">
                            <div class="action-buttons">
                                <button onclick="viewStudentDetails(<?php echo $row['id']; ?>, <?php echo htmlspecialchars(json_encode($row)); ?>)" 
                                        class="btn-sm btn-view">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                <a href="?delete=<?php echo $row['id']; ?>" 
                                   class="btn-sm btn-danger" 
                                   onclick="return confirm('Are you sure you want to delete <?php echo addslashes($row['name']); ?>? This action cannot be undone.')">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="no-data">
            <i class="fas fa-users"></i>
            <h3>No Students Found</h3>
            <p>Add student to get started</p>
            <button class="btn-primary" onclick="openModal('addStudentModal')" style="margin-top: 20px;">
                <i class="fas fa-user-plus"></i> Add Student
            </button>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add Student Modal -->
<div id="addStudentModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-user-plus"></i> Add New Student</h3>
            <button class="close-modal" onclick="closeModal('addStudentModal')">&times;</button>
        </div>
        <form method="POST" action="students.php" onsubmit="return validatePhoneNumber(this.phone.value)">
            <div class="form-group">
                <label>Full Name *</label>
                <input type="text" name="name" class="form-control" placeholder="Enter full name" required>
            </div>
            
            <div class="form-group">
                <label>Email Address *</label>
                <input type="email" name="email" class="form-control" placeholder="Enter email address" required>
            </div>
            
            <div class="form-group">
                <label>Phone Number * (10 digits only)</label>
                <input type="tel" name="phone" class="form-control" placeholder="Enter 10 digit phone number" 
                       pattern="[0-9]{10}" maxlength="10" minlength="10" 
                       title="Please enter exactly 10 digits" required 
                       onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                <small style="color: #7f8c8d;">Only 10 digits allowed (numbers only)</small>
            </div>
            
            <div class="form-group">
                <label>Gender *</label>
                <select name="gender" class="form-control" required>
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Education *</label>
                <input type="text" name="education" class="form-control" 
                       placeholder="e.g., B.Tech Computer Science" required>
            </div>
            
            <div class="form-group">
                <label>City</label>
                <input type="text" name="city" class="form-control" placeholder="Enter city name">
            </div>
            
            <div class="modal-footer" style="padding: 20px 25px 25px 25px;">
                <button type="button" class="btn-secondary" onclick="closeModal('addStudentModal')">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="submit" name="add_student" class="btn-primary">
                    <i class="fas fa-save"></i> Add Student
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Student Details Modal (View & Edit in One) -->
<div id="studentDetailModal" class="modal student-detail-modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-user-graduate"></i> Student Details</h3>
            <button class="close-modal" onclick="closeModal('studentDetailModal')">&times;</button>
        </div>
        
        <!-- This will be populated with student data -->
        <div id="studentDetailContent" style="padding: 20px; max-height: 70vh; overflow-y: auto;">
            <div style="text-align: center; padding: 40px;">
                <i class="fas fa-spinner fa-spin" style="font-size: 32px; color: #667eea;"></i>
                <p style="margin-top: 15px; color: #6c757d;">Loading student details...</p>
            </div>
        </div>
    </div>
</div>

<script>
// Phone number validation function
function validatePhoneNumber(phone) {
    // Remove any non-digit characters
    const cleaned = phone.replace(/\D/g, '');
    
    if (cleaned.length !== 10) {
        alert('Phone number must be exactly 10 digits');
        return false;
    }
    
    if (isNaN(cleaned)) {
        alert('Phone number must contain only digits');
        return false;
    }
    
    return true;
}

// Global variable to store current student data
let currentStudentData = null;

// View Student Details in Modal - FIXED: No page locking
function viewStudentDetails(studentId, studentData) {
    const modal = document.getElementById('studentDetailModal');
    const content = document.getElementById('studentDetailContent');
    
    // Store current student data
    currentStudentData = studentData;
    
    // Display student details immediately with the passed data
    displayStudentDetails(studentId, studentData);
    
    modal.style.display = 'block';
    // REMOVED: document.body.style.overflow = 'hidden'; - Page stays scrollable
}

// Display student details with edit form
function displayStudentDetails(studentId, student) {
    const content = document.getElementById('studentDetailContent');
    const salutation = student.gender === 'Female' ? 'Ms.' : 'Mr.';
    const fullName = salutation + ' ' + student.name;
    const initial = student.name.charAt(0).toUpperCase();
    
    let html = `
        <!-- Student Profile Header -->
        <div class="student-profile-header">
            <button class="edit-mode-btn" onclick="toggleEditMode()" id="editModeBtn">
                <i class="fas fa-edit"></i> Edit Information
            </button>
            <div class="student-avatar-large">
                ${initial}
            </div>
            <h2 style="margin: 10px 0 5px 0;">${escapeHtml(fullName)}</h2>
            <p style="margin: 0; opacity: 0.9;">
                <i class="fas fa-envelope"></i> ${escapeHtml(student.email)} | 
                <i class="fas fa-phone"></i> ${escapeHtml(student.phone)}
            </p>
        </div>
        
        <!-- View Mode (Default) -->
        <div id="viewModeContent">
            <!-- Personal Information -->
            <div class="detail-section">
                <h4><i class="fas fa-user"></i> Personal Information</h4>
                <div class="detail-grid">
                    <div class="detail-item">
                        <span class="detail-label">Full Name</span>
                        <span class="detail-value">${escapeHtml(student.name)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Gender</span>
                        <span class="detail-value">${student.gender}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Education</span>
                        <span class="detail-value">${escapeHtml(student.education)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Email</span>
                        <span class="detail-value">${escapeHtml(student.email)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Phone</span>
                        <span class="detail-value">${escapeHtml(student.phone)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">City</span>
                        <span class="detail-value">${student.city ? escapeHtml(student.city) : 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Registered On</span>
                        <span class="detail-value">${formatDate(student.created_at)}</span>
                    </div>
                </div>
            </div>
    `;
    
    // Courses Information (simplified)
    html += `
        <div class="detail-section">
            <h4><i class="fas fa-book"></i> Enrolled Courses</h4>
            <div id="coursesList">
                <div style="text-align: center; padding: 20px; color: #6c757d;">
                    <i class="fas fa-info-circle"></i> Course information will be displayed here
                </div>
            </div>
        </div>
    </div>
    
    <!-- Edit Mode (Hidden by Default) -->
    <div id="editModeContent" class="edit-form-section">
        <h4><i class="fas fa-edit"></i> Edit Student Information</h4>
        <form method="POST" action="" onsubmit="return validateEditForm()">
            <input type="hidden" name="student_id" value="${student.id}">
            <input type="hidden" name="update_student" value="1">
            
            <div class="form-group">
                <label>Full Name *</label>
                <input type="text" name="name" class="form-control" value="${escapeHtml(student.name)}" required>
            </div>
            
            <div class="form-group">
                <label>Email Address *</label>
                <input type="email" name="email" class="form-control" value="${escapeHtml(student.email)}" required>
            </div>
            
            <div class="form-group">
                <label>Phone Number * (10 digits only)</label>
                <input type="tel" name="phone" class="form-control" value="${escapeHtml(student.phone)}" 
                       pattern="[0-9]{10}" maxlength="10" minlength="10" 
                       title="Please enter exactly 10 digits" required
                       onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                <small style="color: #7f8c8d;">Only 10 digits allowed (numbers only)</small>
            </div>
            
            <div class="form-group">
                <label>Gender *</label>
                <select name="gender" class="form-control" required>
                    <option value="Male" ${student.gender === 'Male' ? 'selected' : ''}>Male</option>
                    <option value="Female" ${student.gender === 'Female' ? 'selected' : ''}>Female</option>
                    <option value="Other" ${student.gender === 'Other' ? 'selected' : ''}>Other</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Education *</label>
                <input type="text" name="education" class="form-control" value="${escapeHtml(student.education)}" required>
            </div>
            
            <div class="form-group">
                <label>City</label>
                <input type="text" name="city" class="form-control" value="${escapeHtml(student.city || '')}" placeholder="Enter city name">
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                <button type="button" class="btn-secondary" onclick="cancelEdit()">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn-success">
                    <i class="fas fa-save"></i> UPDATE
                </button>
            </div>
        </form>
    </div>
    
    <!-- Modal Actions -->
    <div class="modal-actions">
        <button onclick="closeModal('studentDetailModal')" class="btn-secondary">
            <i class="fas fa-times"></i> Close
        </button>
    </div>
    `;
    
    content.innerHTML = html;
}

// Toggle between view and edit modes
function toggleEditMode() {
    const viewMode = document.getElementById('viewModeContent');
    const editMode = document.getElementById('editModeContent');
    const editBtn = document.getElementById('editModeBtn');
    
    if (viewMode && editMode) {
        if (viewMode.style.display === 'none' || viewMode.style.display === '') {
            // Switch to view mode
            viewMode.style.display = 'block';
            editMode.style.display = 'none';
            editBtn.innerHTML = '<i class="fas fa-edit"></i> Edit Information';
        } else {
            // Switch to edit mode
            viewMode.style.display = 'none';
            editMode.style.display = 'block';
            editBtn.innerHTML = '<i class="fas fa-eye"></i> View Information';
        }
    }
}

// Cancel edit and return to view mode
function cancelEdit() {
    const viewMode = document.getElementById('viewModeContent');
    const editMode = document.getElementById('editModeContent');
    const editBtn = document.getElementById('editModeBtn');
    
    if (viewMode && editMode) {
        viewMode.style.display = 'block';
        editMode.style.display = 'none';
        editBtn.innerHTML = '<i class="fas fa-edit"></i> Edit Information';
    }
}

// Validate edit form
function validateEditForm() {
    // Get form elements directly from the edit form
    const editForm = document.querySelector('#editModeContent form');
    if (!editForm) {
        alert('Form not found');
        return false;
    }
    
    const nameInput = editForm.querySelector('input[name="name"]');
    const emailInput = editForm.querySelector('input[name="email"]');
    const phoneInput = editForm.querySelector('input[name="phone"]');
    
    if (!nameInput || !emailInput || !phoneInput) {
        alert('Form fields not found');
        return false;
    }
    
    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    const phone = phoneInput.value.trim();
    
    if (name === '') {
        alert('Please enter student name');
        nameInput.focus();
        return false;
    }
    
    if (email === '') {
        alert('Please enter email address');
        emailInput.focus();
        return false;
    }
    
    if (!email.includes('@') || !email.includes('.')) {
        alert('Please enter a valid email address');
        emailInput.focus();
        return false;
    }
    
    // Phone number validation
    const phoneDigits = phone.replace(/\D/g, '');
    if (phoneDigits.length !== 10) {
        alert('Phone number must be exactly 10 digits');
        phoneInput.focus();
        return false;
    }
    
    if (isNaN(phoneDigits)) {
        alert('Phone number must contain only digits');
        phoneInput.focus();
        return false;
    }
    
    // If all validations pass
    return true;
}

// Helper function to escape HTML
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Helper function to format date
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' });
}

// Modal Functions - FIXED: No page locking
function openModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
    // REMOVED: document.body.style.overflow = 'hidden'; - Page stays scrollable
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
    // REMOVED: document.body.style.overflow = 'auto'; - Not needed
}

// Close modal when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        closeModal(event.target.id);
    }
};

// Form validation for add student
document.addEventListener('DOMContentLoaded', function() {
    const addForm = document.querySelector('#addStudentModal form');
    if (addForm) {
        addForm.addEventListener('submit', function(e) {
            const name = document.querySelector('input[name="name"]').value.trim();
            const email = document.querySelector('input[name="email"]').value.trim();
            const phone = document.querySelector('input[name="phone"]').value.trim();
            
            if (name === '') {
                e.preventDefault();
                alert('Please enter student name');
                return;
            }
            
            if (email === '') {
                e.preventDefault();
                alert('Please enter email address');
                return;
            }
            
            if (!email.includes('@') || !email.includes('.')) {
                e.preventDefault();
                alert('Please enter a valid email address');
                return;
            }
            
            // Phone number validation
            const phoneDigits = phone.replace(/\D/g, '');
            if (phoneDigits.length !== 10) {
                e.preventDefault();
                alert('Phone number must be exactly 10 digits');
                return;
            }
            
            if (isNaN(phoneDigits)) {
                e.preventDefault();
                alert('Phone number must contain only digits');
                return;
            }
        });
    }
});
</script>

<?php 
$conn->close();
require_once 'footer.php'; 
?>