<?php
require_once 'header.php';

$conn = getConnection();

// Get counts
$students_count = $conn->query("SELECT COUNT(*) as total FROM students")->fetch_assoc()['total'];
$courses_count = $conn->query("SELECT COUNT(*) as total FROM courses")->fetch_assoc()['total'];
$batches_count = $conn->query("SELECT COUNT(*) as total FROM batches")->fetch_assoc()['total'];
$certificates_count = $conn->query("SELECT COUNT(*) as total FROM certificates")->fetch_assoc()['total'];

// Get recent students (increased to 10)
$recent_students = $conn->query("SELECT * FROM students ORDER BY created_at DESC LIMIT 10");
// Get recent courses (increased to 6 for horizontal display)
$recent_courses = $conn->query("SELECT * FROM courses ORDER BY created_at DESC LIMIT 6");

$conn->close();
?>

<!-- Dashboard Content -->
<div class="dashboard-content">
    <!-- Welcome Section -->
    <div class="welcome-card card">
        <div style="display: flex; align-items: center; gap: 20px;">
            <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                  border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 32px;">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <div>
                <h2 style="color: #2c3e50; margin-bottom: 5px;">Welcome back, <?php echo $_SESSION['admin_name']; ?>!</h2>
                <p style="color: #000000;">Here's what's happening with your internship program today.</p>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="stats-grid">
        <div class="stat-card card" style="border-left: 4px solid #4CAF50;">
            <div class="stat-header">
                <h3><i class="fas fa-users" style="color: #4CAF50;"></i> Total Students</h3>
            </div>
            <div class="stat-body">
                <h2><?php echo $students_count; ?></h2>
                <p>Registered students</p>
            </div>
            <div class="stat-footer">
                <a href="students.php" class="stat-link">View All <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

        <div class="stat-card card" style="border-left: 4px solid #2196F3;">
            <div class="stat-header">
                <h3><i class="fas fa-book" style="color: #2196F3;"></i> Total Courses</h3>
            </div>
            <div class="stat-body">
                <h2><?php echo $courses_count; ?></h2>
                <p>Available courses</p>
            </div>
            <div class="stat-footer">
                <a href="courses.php" class="stat-link">View All <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

        <div class="stat-card card" style="border-left: 4px solid #FF9800;">
            <div class="stat-header">
                <h3><i class="fas fa-layer-group" style="color: #FF9800;"></i> Total Batches</h3>
            </div>
            <div class="stat-body">
                <h2><?php echo $batches_count; ?></h2>
                <p>Active batches</p>
            </div>
            <div class="stat-footer">
                <a href="batches.php" class="stat-link">View All <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

        <div class="stat-card card" style="border-left: 4px solid #9C27B0;">
            <div class="stat-header">
                <h3><i class="fas fa-certificate" style="color: #9C27B0;"></i> Certificates</h3>
            </div>
            <div class="stat-body">
                <h2><?php echo $certificates_count; ?></h2>
                <p>Issued certificates</p>
            </div>
            <div class="stat-footer">
                <a href="certificates.php" class="stat-link">View All <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>
    </div>

    <!-- Main Content Grid -->
    <div class="content-grid">
        <!-- Recent Students -->
        <div class="card" style="grid-column: span 2;">
            <div class="card-header">
                <h3><i class="fas fa-user-clock"></i> Recent Students (Last 10 Registered)</h3>
                <a href="students.php" class="btn-primary" style="padding: 8px 15px; font-size: 14px;">
                    <i class="fas fa-eye"></i> View All Students
                </a>
            </div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Gender</th>
                            <th>Education</th>
                            <th>Joined Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($recent_students->num_rows > 0): ?>
                            <?php while($student = $recent_students->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $student['id']; ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 35px; height: 35px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                                              border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 14px;">
                                            <?php echo strtoupper(substr($student['name'], 0, 1)); ?>
                                        </div>
                                        <span style="font-weight: 500;"><?php echo htmlspecialchars($student['name']); ?></span>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($student['email']); ?></td>
                                <td><?php echo htmlspecialchars($student['phone']); ?></td>
                                <td>
                                    <span class="badge <?php echo $student['gender'] == 'Male' ? 'badge-info' : ($student['gender'] == 'Female' ? 'badge-warning' : 'badge-secondary'); ?>" 
                                          style="font-size: 11px; padding: 3px 8px;">
                                        <?php echo $student['gender']; ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($student['education']); ?></td>
                                <td><?php echo date('d M Y', strtotime($student['created_at'])); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 20px; color: #7f8c8d;">
                                    <i class="fas fa-users" style="font-size: 24px; margin-bottom: 10px; display: block;"></i>
                                    No students registered yet
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Recent Courses in Horizontal Boxes -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-book-open"></i> Recent Courses</h3>
                <a href="courses.php" class="btn-primary" style="padding: 8px 15px; font-size: 14px;">
                    <i class="fas fa-eye"></i> View All
                </a>
            </div>
            <div style="padding: 20px;">
                <?php if($recent_courses->num_rows > 0): ?>
                    <div class="courses-horizontal-grid">
                        <?php while($course = $recent_courses->fetch_assoc()): 
                            // Different colors for different course statuses
                            $bg_color = $course['status'] == 'active' ? 'linear-gradient(135deg, #4CAF50, #2E7D32)' : 'linear-gradient(135deg, #FF9800, #E65100)';
                            $status_class = $course['status'] == 'active' ? 'active' : 'completed';
                        ?>
                        <div class="course-horizontal-box" style="background: <?php echo $bg_color; ?>;">
                            <div class="course-box-header">
                                <div class="course-icon-box">
                                    <i class="fas fa-book"></i>
                                </div>
                                <div class="course-status">
                                    <span class="status-badge <?php echo $status_class; ?>">
                                        <?php echo ucfirst($course['status']); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="course-box-body">
                                <h4><?php echo htmlspecialchars($course['name']); ?></h4>
                                <p class="course-description">
                                    <?php echo substr(htmlspecialchars($course['description']), 0, 80); ?>
                                    <?php if(strlen($course['description']) > 80): ?>...<?php endif; ?>
                                </p>
                            </div>
                            <div class="course-box-footer">
                                <div class="course-dates">
                                    
                                </div>
                                <a href="batches.php?course_id=<?php echo $course['id']; ?>" class="course-action-btn">
                                    <i class="fas fa-layer-group"></i> View Batches
                                </a>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div style="text-align: center; padding: 30px; color: #7f8c8d;">
                        <i class="fas fa-book" style="font-size: 48px; margin-bottom: 15px; opacity: 0.5; display: block;"></i>
                        <p>No courses created yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    

<style>
.dashboard-content {
    padding: 0;
}

.welcome-card {
    margin-bottom: 30px;
    padding: 30px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.welcome-card h2,
.welcome-card p {
    color: white;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    padding: 20px;
    transition: transform 0.3s, box-shadow 0.3s;
    cursor: pointer;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.stat-header h3 {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 16px;
    color: #2c3e50;
    margin-bottom: 15px;
}

.stat-body h2 {
    font-size: 36px;
    color: #2c3e50;
    margin: 0;
}

.stat-body p {
    color: #7f8c8d;
    margin: 5px 0 15px 0;
    font-size: 14px;
}

.stat-footer {
    border-top: 1px solid #eee;
    padding-top: 15px;
}

.stat-link {
    color: #667eea;
    text-decoration: none;
    font-size: 14px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 5px;
}

.stat-link:hover {
    color: #764ba2;
}

.content-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 20px;
    margin-bottom: 30px;
}

/* Recent Courses Horizontal Boxes */
.courses-horizontal-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 15px;
}

.course-horizontal-box {
    border-radius: 10px;
    padding: 20px;
    color: white;
    transition: transform 0.3s, box-shadow 0.3s;
    display: flex;
    flex-direction: column;
    min-height: 250px;
}

.course-horizontal-box:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.course-box-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 15px;
}

.course-icon-box {
    width: 50px;
    height: 50px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
}

.course-status .status-badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.course-status .status-badge.active {
    background: rgba(255, 255, 255, 0.2);
    color: white;
}

.course-status .status-badge.completed {
    background: rgba(255, 255, 255, 0.2);
    color: white;
}

.course-box-body {
    flex: 1;
    margin-bottom: 20px;
}

.course-box-body h4 {
    font-size: 18px;
    margin: 0 0 10px 0;
    line-height: 1.4;
    color: white;
}

.course-description {
    font-size: 13px;
    line-height: 1.5;
    opacity: 0.9;
    margin: 0;
    color: white;
}

.course-box-footer {
    border-top: 1px solid rgba(255, 255, 255, 0.2);
    padding-top: 15px;
}

.course-dates {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-bottom: 15px;
}

.date-item {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
    opacity: 0.9;
}

.date-item i {
    font-size: 10px;
}

.course-action-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 8px 15px;
    background: rgba(255, 255, 255, 0.2);
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-size: 13px;
    font-weight: 500;
    transition: background 0.3s;
    width: 100%;
    text-align: center;
}

.course-action-btn:hover {
    background: rgba(255, 255, 255, 0.3);
    color: white;
}

.system-status {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
}

.status-item {
    display: flex;
    align-items: center;
    gap: 15px;
}

.status-indicator {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #4CAF50;
}

.status-indicator.active {
    background: #4CAF50;
    box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.2);
}

.status-indicator.inactive {
    background: #f44336;
    box-shadow: 0 0 0 3px rgba(244, 67, 54, 0.2);
}

.status-text h4 {
    margin: 0 0 5px 0;
    color: #2c3e50;
    font-size: 16px;
}

.status-text p {
    margin: 0;
    color: #7f8c8d;
    font-size: 14px;
}

/* Badge styles */
.badge-info {
    background: #d1ecf1;
    color: #0c5460;
}

.badge-warning {
    background: #fff3cd;
    color: #856404;
}

.badge-secondary {
    background: #6c757d;
    color: white;
}

/* Responsive adjustments */
@media (max-width: 1024px) {
    .content-grid {
        grid-template-columns: 1fr;
    }
    
    .courses-horizontal-grid {
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    }
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .courses-horizontal-grid {
        grid-template-columns: 1fr;
    }
    
    .system-status {
        grid-template-columns: 1fr;
    }
    
    .course-dates {
        grid-template-columns: 1fr;
    }
}

@media (min-width: 769px) and (max-width: 1200px) {
    .courses-horizontal-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}
</style>

<?php require_once 'footer.php'; ?>