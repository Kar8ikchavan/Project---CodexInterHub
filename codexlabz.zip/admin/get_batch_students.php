<?php
require_once 'header.php';

$conn = getConnection();

$batch_id = isset($_GET['batch_id']) ? intval($_GET['batch_id']) : 0;

if ($batch_id > 0) {
    // Get students enrolled in this batch
    $students = $conn->query("SELECT s.id, s.name, s.email 
                              FROM students s 
                              JOIN batch_students bs ON s.id = bs.student_id 
                              WHERE bs.batch_id = $batch_id 
                              ORDER BY s.name");
    
    $options = '<option value="">Select Student</option>';
    
    if ($students && $students->num_rows > 0) {
        while ($student = $students->fetch_assoc()) {
            $options .= '<option value="' . $student['id'] . '">' . htmlspecialchars($student['name']) . ' (' . htmlspecialchars($student['email']) . ')</option>';
        }
    } else {
        $options = '<option value="">No students found in this batch</option>';
    }
    
    echo $options;
} else {
    echo '<option value="">Invalid batch</option>';
}

$conn->close();
?>