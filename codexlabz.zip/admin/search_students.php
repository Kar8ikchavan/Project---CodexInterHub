<?php
require_once 'header.php';

$conn = getConnection();

if ($search && strlen($search) >= 2) {
    $search_term = $conn->real_escape_string($search);
    $sql = "SELECT id, name, email FROM students 
            WHERE name LIKE '%$search_term%' OR email LIKE '%$search_term%' 
            ORDER BY name LIMIT 10";
    
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        while($student = $result->fetch_assoc()) {
            echo '<div class="search-result-item" data-id="' . $student['id'] . '">';
            echo '<div style="font-weight: 500;">' . htmlspecialchars($student['name']) . '</div>';
            echo '<div style="font-size: 12px; color: #7f8c8d;">' . htmlspecialchars($student['email']) . '</div>';
            echo '</div>';
        }
    } else {
        echo '<div style="padding: 15px; color: #7f8c8d; text-align: center;">No students found</div>';
    }
} else {
    echo '<div style="padding: 15px; color: #7f8c8d; text-align: center;">Type at least 2 characters to search</div>';
}

$conn->close();
?>