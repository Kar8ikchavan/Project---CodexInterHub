<?php
session_start();

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'u137169874_codex');
define('DB_PASS', 'Codex@1208');
define('DB_NAME', 'u137169874_codex');

// Create connection
function getConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    return $conn;
}

// Authentication functions
function isLoggedIn() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: ../index.php");
        exit();
    }
}

function logout() {
    session_destroy();
    header("Location: ../index.php");
    exit();
}

// Handle logout
if (isset($_GET['logout'])) {
    logout();
}
?>