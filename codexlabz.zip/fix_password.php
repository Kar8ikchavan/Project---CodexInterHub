<?php
// Fix password script
$conn = new mysqli('localhost', 'root', '', 'codexlabz_internship');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Generate proper hash for 'admin123'
$password = 'admin123';
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

echo "New hash for 'admin123': $hashed_password<br><br>";

// Update admin password
$sql = "UPDATE admin SET password = '$hashed_password' WHERE username = 'admin'";

if ($conn->query($sql) === TRUE) {
    echo "Password updated successfully!<br>";
    
    // Verify it works
    $result = $conn->query("SELECT password FROM admin WHERE username = 'admin'");
    $row = $result->fetch_assoc();
    
    echo "Stored hash: " . $row['password'] . "<br>";
    echo "Password verify test: " . (password_verify('admin123', $row['password']) ? 'SUCCESS ✓' : 'FAILED ✗');
} else {
    echo "Error: " . $conn->error;
}

$conn->close();

echo "<br><br><a href='index.php'>Go to Login Page</a>";
?>