<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../db.php';

$conn = getConnection();

// Get the certificate code from URL
$certificate_code = isset($_GET['ref']) ? trim($_GET['ref']) : '';

if (!empty($certificate_code)) {
    // Directly use certificate_code to find the certificate
    $sql = "SELECT c.*, s.name as student_name, s.gender, s.email, s.phone, s.education, s.city, s.created_at as student_registered,
                   cr.name as course_name, cr.start_date as course_start, cr.end_date as course_end, 
                   b.batch_code, b.start_date as batch_start, b.end_date as batch_end
            FROM certificates c
            JOIN students s ON c.student_id = s.id
            JOIN courses cr ON c.course_id = cr.id
            LEFT JOIN batches b ON c.batch_id = b.id
            WHERE c.certificate_code = '$certificate_code'";
    
    $result = $conn->query($sql);
    
    // Check for SQL errors
    if (!$result) {
        die("SQL Error: " . $conn->error);
    }
    
    if ($result->num_rows == 1) {
        $certificate = $result->fetch_assoc();
        $student = $certificate; // For easier reference
        $salutation = ($student['gender'] == 'Female') ? 'Ms.' : 'Mr.';
        
        // Format dates
        function formatDate($date) {
            if (!$date || $date == '0000-00-00') return 'N/A';
            return date('d M Y', strtotime($date));
        }
        
        // Use batch dates if available, otherwise use course dates
        $course_start_display = !empty($student['batch_start']) ? $student['batch_start'] : $student['course_start'];
        $course_end_display = !empty($student['batch_end']) ? $student['batch_end'] : $student['course_end'];
        
    } else {
        // Certificate not found
        $error_message = "Certificate not found with code: " . htmlspecialchars($certificate_code);
    }
} else {
    // No reference provided
    $error_message = "No certificate reference provided";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate Verification</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        
        .container {
            max-width: 800px;
            width: 100%;
        }
        
        .error-box {
            background: white;
            border-radius: 12px;
            padding: 40px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border-left: 5px solid #f44336;
        }
        
        .error-box i {
            font-size: 64px;
            color: #f44336;
            margin-bottom: 20px;
        }
        
        .error-box h2 {
            color: #f44336;
            margin-bottom: 15px;
        }
        
        .error-box p {
            color: #666;
            margin-bottom: 25px;
            line-height: 1.6;
        }
        
        .error-box .code {
            background: #f5f5f5;
            padding: 10px;
            border-radius: 5px;
            font-family: monospace;
            color: #333;
            margin: 20px 0;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 25px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }
        
        .success-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .avatar {
            width: 100px;
            height: 100px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            font-weight: bold;
            color: #667eea;
            margin: 0 auto 15px;
            border: 4px solid rgba(255,255,255,0.3);
        }
        
        .header h2 {
            margin: 10px 0 5px;
            font-size: 28px;
        }
        
        .header p {
            margin: 5px 0;
            opacity: 0.9;
        }
        
        .body {
            padding: 30px;
        }
        
        .section {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 25px;
        }
        
        .section h3 {
            margin: 0 0 15px 0;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 2px solid #dee2e6;
            padding-bottom: 10px;
        }
        
        .grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        
        .item {
            display: flex;
            flex-direction: column;
        }
        
        .label {
            font-size: 12px;
            color: #7f8c8d;
            margin-bottom: 5px;
            text-transform: uppercase;
        }
        
        .value {
            font-weight: 600;
            color: #2c3e50;
            font-size: 16px;
        }
        
        .badge {
            background: #e3f2fd;
            color: #1976d2;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 13px;
            display: inline-block;
            margin-top: 5px;
        }
        
        .verification-banner {
            background: linear-gradient(135deg, #1a237e, #283593);
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .verification-text {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .verification-text i {
            font-size: 24px;
        }
        
        .status {
            background: #4CAF50;
            padding: 6px 15px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 13px;
        }
        
        @media (max-width: 768px) {
            .grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (isset($error_message)): ?>
            <!-- Error Display -->
            <div class="error-box">
                <i class="fas fa-exclamation-circle"></i>
                <h2>Certificate Not Found</h2>
                <p><?php echo $error_message; ?></p>
                <?php if (!empty($certificate_code)): ?>
                    <div class="code">
                        <strong>Code:</strong> <?php echo htmlspecialchars($certificate_code); ?>
                    </div>
                <?php endif; ?>
                
            </div>
        <?php elseif (isset($student)): ?>
            <!-- Success - Show Student Details -->
            <div class="verification-banner">
                <div class="verification-text">
                    <i class="fas fa-shield-alt"></i>
                    <div>
                        <h3 style="margin: 0 0 5px 0;">Verified Certificate</h3>
                        <p style="margin: 0; opacity: 0.9;">This is an official certificate issued by CodexLabz</p>
                    </div>
                </div>
                <div class="status">
                    <i class="fas fa-check-circle"></i> VERIFIED
                </div>
            </div>
            
            <div class="success-card">
                <div class="header">
                    <div class="avatar">
                        <?php echo strtoupper(substr($student['student_name'], 0, 1)); ?>
                    </div>
                    <h2><?php echo $salutation . ' ' . htmlspecialchars($student['student_name']); ?></h2>
                    <p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($student['email']); ?></p>
                    <p><i class="fas fa-phone"></i> <?php echo htmlspecialchars($student['phone']); ?></p>
                    <div style="margin-top: 10px;">
                        <span class="badge">
                            <i class="fas fa-certificate"></i> <?php echo htmlspecialchars($student['certificate_code']); ?>
                        </span>
                    </div>
                </div>
                
                <div class="body">
                    <!-- Student Information -->
                    <div class="section">
                        <h3><i class="fas fa-user"></i> Student Information</h3>
                        <div class="grid">
                            <div class="item">
                                <span class="label">Full Name</span>
                                <span class="value"><?php echo htmlspecialchars($student['student_name']); ?></span>
                            </div>
                            <div class="item">
                                <span class="label">Gender</span>
                                <span class="value"><?php echo $student['gender']; ?></span>
                            </div>
                            <div class="item">
                                <span class="label">Email</span>
                                <span class="value"><?php echo htmlspecialchars($student['email']); ?></span>
                            </div>
                            <div class="item">
                                <span class="label">Phone</span>
                                <span class="value"><?php echo htmlspecialchars($student['phone']); ?></span>
                            </div>
                            <div class="item">
                                <span class="label">Education</span>
                                <span class="value"><?php echo htmlspecialchars($student['education']); ?></span>
                            </div>
                            <div class="item">
                                <span class="label">City</span>
                                <span class="value"><?php echo !empty($student['city']) ? htmlspecialchars($student['city']) : 'N/A'; ?></span>
                            </div>
                            <div class="item">
                                <span class="label">Registered On</span>
                                <span class="value"><?php echo formatDate($student['student_registered']); ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Course Information -->
                    <div class="section">
                        <h3><i class="fas fa-graduation-cap"></i> Course Information</h3>
                        <div class="grid">
                            <div class="item">
                                <span class="label">Course Name</span>
                                <span class="value"><?php echo htmlspecialchars($student['course_name']); ?></span>
                            </div>
                            <div class="item">
                                <span class="label">Batch Code</span>
                                <span class="value"><?php echo !empty($student['batch_code']) ? htmlspecialchars($student['batch_code']) : 'N/A'; ?></span>
                            </div>
                            <div class="item">
                                <span class="label">Course Duration</span>
                                <span class="value"><?php echo formatDate($course_start_display) . ' - ' . formatDate($course_end_display); ?></span>
                            </div>
                            <div class="item">
                                <span class="label">Certificate Code</span>
                                <span class="value"><?php echo htmlspecialchars($student['certificate_code']); ?></span>
                            </div>
                            <div class="item">
                                <span class="label">Issue Date</span>
                                <span class="value"><?php echo formatDate($student['issue_date']); ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div style="text-align: center; margin-top: 20px;">
                        <a href="https://www.codexlabz.com" target="_blank" class="btn" style="background: linear-gradient(135deg, #4CAF50, #45a049);">
                            <i class="fas fa-globe"></i> Visit Website
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>