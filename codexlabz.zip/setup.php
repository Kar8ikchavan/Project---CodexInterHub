<?php
echo "<h2>CodexLabz Internship System Setup</h2>";

// Check if MySQL is running
$mysql_ports = [3306, 3307, 3308];
$mysql_running = false;

foreach ($mysql_ports as $port) {
    $connection = @fsockopen('localhost', $port);
    if (is_resource($connection)) {
        $mysql_running = true;
        fclose($connection);
        break;
    }
}

if (!$mysql_running) {
    echo "<div style='color: red; padding: 10px; background: #ffcccc; border: 1px solid red;'>
        <strong>ERROR:</strong> MySQL is not running!<br>
        1. Open XAMPP Control Panel<br>
        2. Click START next to MySQL<br>
        3. Refresh this page
    </div>";
    exit;
}

echo "<div style='color: green; padding: 10px; background: #ccffcc; border: 1px solid green;'>
    ✓ MySQL is running!
</div>";

try {
    $conn = new mysqli('localhost', 'root', '', '');

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    echo "✓ Connected to MySQL server!<br>";

    // Create database
    echo "Creating database...<br>";
    $sql = "CREATE DATABASE IF NOT EXISTS codexlabz_internship 
            CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";

    if ($conn->query($sql) === TRUE) {
        echo "✓ Database created!<br>";
    } else {
        throw new Exception("Error creating database: " . $conn->error);
    }

    $conn->select_db('codexlabz_internship');

    echo "Creating tables...<br>";

    $tables = [

        // Disable foreign key checks
        "SET FOREIGN_KEY_CHECKS = 0",

        "DROP TABLE IF EXISTS certificates",
        "DROP TABLE IF EXISTS batch_students",
        "DROP TABLE IF EXISTS batches",
        "DROP TABLE IF EXISTS courses",
        "DROP TABLE IF EXISTS students",
        "DROP TABLE IF EXISTS admin",

        // Enable again
        "SET FOREIGN_KEY_CHECKS = 1",

        // Admin table
        "CREATE TABLE admin (
            id INT PRIMARY KEY AUTO_INCREMENT,
            username VARCHAR(50) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            full_name VARCHAR(100) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )",

        // Students
        "CREATE TABLE students (
            id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            phone VARCHAR(15) NOT NULL,
            gender ENUM('Male', 'Female', 'Other') NOT NULL,
            education VARCHAR(100) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )",

        // Courses
        "CREATE TABLE courses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    course_fee DECIMAL(10,2) DEFAULT 0,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status ENUM('active', 'completed') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
",

        // Batches
        "CREATE TABLE batches (
            id INT PRIMARY KEY AUTO_INCREMENT,
            course_id INT NOT NULL,
            batch_name VARCHAR(100) NOT NULL,
            batch_code VARCHAR(20) UNIQUE NOT NULL,
            start_date DATE NOT NULL,
            end_date DATE NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
        )",

        // Batch Students
        "CREATE TABLE batch_students (
            id INT PRIMARY KEY AUTO_INCREMENT,
            batch_id INT NOT NULL,
            student_id INT NOT NULL,
            enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE CASCADE,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            UNIQUE KEY unique_enrollment (batch_id, student_id)
        )",

        // Certificates
        "CREATE TABLE certificates (
            id INT PRIMARY KEY AUTO_INCREMENT,
            certificate_code VARCHAR(50) UNIQUE NOT NULL,
            student_id INT NOT NULL,
            course_id INT NOT NULL,
            batch_id INT,
            issue_date DATE NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
            FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE SET NULL
        )"
    ];

    foreach ($tables as $sql) {
        if ($conn->query($sql) === TRUE) {
            echo "✓ Table operation successful<br>";
        } else {
            throw new Exception("Error: " . $conn->error);
        }
    }

    // Create admin account
    echo "Creating admin account...<br>";
    $password = 'admin123';
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO admin (username, password, full_name) VALUES 
            ('admin', '$hashed_password', 'System Administrator')";

    if ($conn->query($sql) === TRUE) {
        echo "✓ Admin account created!<br>";
    } else {
        $sql = "UPDATE admin SET password = '$hashed_password' WHERE username = 'admin'";
        $conn->query($sql);
        echo "✓ Admin password updated!<br>";
    }

    // Sample data
    echo "Adding sample data...<br>";

    $sample_data = [

        "INSERT INTO students (name, email, phone, gender, education) VALUES
        ('John Doe', 'john@example.com', '1234567890', 'Male', 'B.Tech Computer Science'),
        ('Jane Smith', 'jane@example.com', '0987654321', 'Female', 'MCA'),
        ('Bob Johnson', 'bob@example.com', '1122334455', 'Male', 'B.Sc IT')",

        "INSERT INTO courses (name, description, start_date, end_date, status) VALUES
        ('Web Development', 'Full stack web development course', '2024-01-01', '2024-06-30', 'completed'),
        ('Data Science', 'Data science and machine learning', '2024-02-01', '2024-07-31', 'active'),
        ('Mobile App Development', 'Android and iOS app development', '2024-03-01', '2024-08-31', 'active')",

        "INSERT INTO batches (course_id, batch_name, batch_code, start_date, end_date) VALUES
        (1, 'Web Dev Batch 1', 'WD-2024-01', '2024-01-01', '2024-06-30'),
        (2, 'Data Science Batch 1', 'DS-2024-01', '2024-02-01', '2024-07-31')"
    ];

    foreach ($sample_data as $sql) {
        $conn->query($sql);
        echo "✓ Sample data added<br>";
    }

    $conn->close();

    echo "<div style='margin-top: 20px; padding: 20px; background: #e7f3ff; border: 2px solid #007bff; border-radius: 5px;'>
        <h3 style='color: green;'>✓ SETUP COMPLETE!</h3>
        <p><strong>Login Details:</strong></p>
        <p>URL: <a href='index.php'>http://localhost/codexlabz_internship/</a></p>
        <p>Username: <strong>admin</strong></p>
        <p>Password: <strong>admin123</strong></p>
    </div>";

} catch (Exception $e) {
    echo "<div style='color: red; padding: 10px; background: #ffcccc; border: 1px solid red;'>
        <strong>ERROR:</strong> " . $e->getMessage() . "<br>
        Make sure MySQL is running in XAMPP!
    </div>";
}
?>
