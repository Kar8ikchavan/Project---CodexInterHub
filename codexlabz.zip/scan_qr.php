<?php
require_once 'config/database.php';
$conn = getConnection();

$certificate_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($certificate_id > 0) {
    $sql = "SELECT c.*, s.name as student_name, s.gender, cr.name as course_name 
            FROM certificates c
            JOIN students s ON c.student_id = s.id
            JOIN courses cr ON c.course_id = cr.id
            WHERE c.id = $certificate_id";
    
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) == 1) {
        $certificate = mysqli_fetch_assoc($result);
        
        // Display certificate information
        echo "<h1>Certificate Verification</h1>";
        echo "<p><strong>Certificate Code:</strong> " . $certificate['certificate_code'] . "</p>";
        echo "<p><strong>Student:</strong> " . $certificate['student_name'] . "</p>";
        echo "<p><strong>Course:</strong> " . $certificate['course_name'] . "</p>";
        echo "<p><strong>Issue Date:</strong> " . $certificate['issue_date'] . "</p>";
    } else {
        echo "<p>Certificate not found!</p>";
    }
} else {
    // Redirect to Hostinger website
    header("Location: https://www.hostinger.com");
    exit();
}
?>